-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: support
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `c_attachments`
--

DROP TABLE IF EXISTS `c_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int DEFAULT NULL,
  `object_type` enum('devices','users','interfaces','pon_boxes','nodes','utels_boxes') NOT NULL,
  `object_id` int NOT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `extension` varchar(50) DEFAULT NULL,
  `extra` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_attachments_users_id_fk` (`user_id`),
  KEY `c_attachments_uuid_index` (`uuid`),
  CONSTRAINT `c_attachments_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_attachments`
--

LOCK TABLES `c_attachments` WRITE;
/*!40000 ALTER TABLE `c_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_autodiscovery_networks`
--

DROP TABLE IF EXISTS `c_autodiscovery_networks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_autodiscovery_networks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_group_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  `cidr` varchar(50) NOT NULL,
  `access_id` int NOT NULL,
  `last_scan` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_autodiscovery_networks_cidr_uindex` (`cidr`,`access_id`),
  KEY `c_autodiscovery_networks_device_accesses_id_fk` (`access_id`),
  KEY `c_autodiscovery_networks_device_groups_id_fk` (`device_group_id`),
  CONSTRAINT `c_autodiscovery_networks_device_accesses_id_fk` FOREIGN KEY (`access_id`) REFERENCES `device_accesses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_autodiscovery_networks_device_groups_id_fk` FOREIGN KEY (`device_group_id`) REFERENCES `device_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_autodiscovery_networks`
--

LOCK TABLES `c_autodiscovery_networks` WRITE;
/*!40000 ALTER TABLE `c_autodiscovery_networks` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_autodiscovery_networks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_console_history`
--

DROP TABLE IF EXISTS `c_console_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_console_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_at` datetime NOT NULL,
  `stop_at` datetime DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `device_id` int DEFAULT NULL,
  `is_autologin` tinyint NOT NULL,
  `log` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `error` json DEFAULT NULL,
  `pid` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_console_history_devices_id_fk` (`device_id`),
  KEY `c_console_history_users_id_fk` (`user_id`),
  KEY `c_console_history_start_at_index` (`start_at`),
  CONSTRAINT `c_console_history_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `c_console_history_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_console_history`
--

LOCK TABLES `c_console_history` WRITE;
/*!40000 ALTER TABLE `c_console_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_console_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_events`
--

DROP TABLE IF EXISTS `c_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `creator_id` int DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `labels` json NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by_id` int DEFAULT NULL,
  `autoresolve_after_min` int NOT NULL DEFAULT '0',
  `is_autoresolved` tinyint DEFAULT NULL,
  `device_id` int DEFAULT NULL,
  `key` varchar(100) NOT NULL,
  `severity` enum('CRITICAL','WARNING','INFO','DEBUG') NOT NULL DEFAULT 'WARNING',
  PRIMARY KEY (`id`),
  KEY `c_events_devices_id_fk` (`device_id`),
  KEY `c_events_users_id_fk` (`creator_id`),
  KEY `c_events_users_id_fk_2` (`resolved_by_id`),
  KEY `c_events_key_index` (`key`),
  KEY `c_events_name_index` (`name`),
  KEY `c_events_resolved_at_index` (`resolved_at`),
  CONSTRAINT `c_events_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_events_users_id_fk` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `c_events_users_id_fk_2` FOREIGN KEY (`resolved_by_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_events`
--

LOCK TABLES `c_events` WRITE;
/*!40000 ALTER TABLE `c_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_events_alertmanager_rules`
--

DROP TABLE IF EXISTS `c_events_alertmanager_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_events_alertmanager_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `alert_name` varchar(150) NOT NULL,
  `expression` varchar(500) NOT NULL,
  `for` varchar(30) NOT NULL,
  `severity` enum('info','warning','critical') NOT NULL,
  `annotation_summary` varchar(500) NOT NULL,
  `annotation_description` varchar(500) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `internal` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_events_alertmanager_rules_alert_name_uindex` (`alert_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10031 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_events_alertmanager_rules`
--

LOCK TABLES `c_events_alertmanager_rules` WRITE;
/*!40000 ALTER TABLE `c_events_alertmanager_rules` DISABLE KEYS */;
INSERT INTO `c_events_alertmanager_rules` VALUES (1,'2023-04-20 16:09:26','2023-04-20 16:09:26','interfaces','iface_increase_in_errors','delta(iface_stat_in_errors[15m]) > 30','10m','warning','Errors increased','Errors increased on {{ $labels.iface_name }} on host {{ $labels.ip }} more than {{ humanize $value }} per 15minutes',1,0),(2,'2023-04-20 16:09:26','2023-04-20 16:09:26','interfaces','iface_increase_out_errors','delta(iface_stat_out_errors[15m]) > 30','30m','warning','Errors increased','Errors increased on {{ $labels.iface_name }} on host {{ $labels.ip }} more than {{ humanize $value }} per 15minutes',1,0),(3,'2023-04-20 16:09:26','2023-04-20 16:09:26','interfaces','interface_is_down','device_interface_status == 0 and device_interface_admin_state == 1','5m','info','Interface is DOWN','Interface {{ $labels.iface_name }} DOWN on host {{ $labels.ip }}',0,0),(4,'2023-04-20 16:09:26','2023-04-20 16:09:26','optical','olt_rx_signal_deteriorated','avg_over_time(optical_olt_rx[1d:1h]) - avg_over_time(optical_olt_rx[30m]) > 2','10m','warning','OLT RX signal deteriorated','OLT RX signal deteriorated on ONU {{ $labels.iface_name }}, OLT {{ $labels.ip }}',1,0),(5,'2023-04-20 16:09:26','2023-04-20 16:09:26','pon','pon_mass_onts_down','round(delta(count(label_replace(device_interface_status{iface_name=~\".*:.*\"}, \"pon_port\", \"$1\", \"iface_name\", \"^(.*):[0-9]{1,4}$\") == 0) by (dev_id, ip, pon_port)[15m:])) >= 3','10m','warning','Mass ONTs is offile on PON port','{{humanize $value}} ONTs was OFFLINE now on device {{ $labels.ip }}, on PON port {{ $labels.pon_port }}',1,0),(6,'2023-04-20 16:09:26','2023-04-20 16:09:26','optical','rx_signal_deteriorated','avg_over_time(optical_rx[1d:1h]) - avg_over_time(optical_rx[30m]) > 2','30m','warning','RX signal deteriorated','RX signal deteriorated on ONU {{ $labels.iface_name }}, OLT {{ $labels.ip }}',1,0),(7,'2023-04-20 16:09:26','2023-04-20 16:09:26','device_resources','sys_cpu_highload','device_resources_cpu_util > 80','15m','warning','CPU highload','CPU on device {{ $labels.ip }} highload, value {{humanize $value}}',1,0),(10000,'2023-04-20 16:09:26','2023-04-20 16:09:26','interfaces','pon_box_status','pon_box_status == 0','1m','info','PON box down','PON box with name {{ $labels.pon_iface }} on device {{ $labels.ip }}, port {{ $labels.pon_iface }} is DOWN',1,0),(10001,'2023-04-20 16:09:26','2023-04-20 16:09:26','router','bgp_session_down','router_bgp_session_state_established == 0 and router_bgp_session_state_disabled == 0','5m','warning','BGP Session Down','BGP session with AS num {{ $labels.remote_as }} ({{ $labels.remote_address }}) on router {{ $labels.router_ip }} DOWN',1,0),(10002,'2023-04-20 16:09:26','2023-04-20 16:09:26','router','bgp_session_restarted','router_bgp_session_uptime < 300 and router_bgp_session_state_established == 1','1m','warning','BGP Session reloaded','BGP session with AS num {{ $labels.remote_as }} ({{ $labels.remote_address }}) on router {{ $labels.router_ip }} RELOADED',1,0),(10003,'2023-04-20 16:09:26','2023-04-20 16:09:26','pinger','pinger_host_down','pinger_host_status <= 0','1m','warning','Device is down by ICMP','Device {{ $labels.ip }} is DOWN',1,0),(10004,'2023-04-20 16:09:26','2023-04-20 16:09:26','pon','pon_ports_is_full','pon_port_current_onts_count / pon_port_max_onts_count * 100 > 90','10m','warning','PON port is full','Port {{ $labels.iface_name }} on host {{ $labels.ip }} loaded to {{ humanize $value }}%',1,0),(10005,'2023-04-20 16:09:26','2023-04-20 16:09:26','system','system_not_enough_pollers','avg_over_time(system_poller_procs_busy_count[10m]) / avg_over_time(system_poller_procs_all_count[10m]) * 100 >= 99','10m','warning','System problem','Not anough processes for pollers. Current pollers load is  {{ humanize $value }}% (You can increase parameter POLLER_COUNT_PROCS in .env or system configuration)',1,0),(10017,'2023-10-03 22:25:26','2023-10-03 22:25:26','interfaces','favorite_interface_down','(device_interface_status == 0 and device_interface_admin_state == 1) * on(iface_id, iface_name, iface_type, ip, dev_id) storage_iface_favorite','2m','warning','Marked interface is DOWN','Interface {{ $labels.iface_name }} DOWN on host {{ $labels.ip }}',1,0),(10018,'2026-08-17 19:17:53','2026-08-17 19:17:53','analytics','bad_optical_level_olt_rx','optical_olt_rx{iface_type=\"ONU\"} > -10 or optical_olt_rx{iface_type=\"ONU\"} < -28','15m','warning','Signal Level Issues','The OLT RX signal level on OLT for ONU {{ $labels.iface_name }}, OLT {{ $labels.ip }} has exceeded the limit - {{ humanize $value }}dBm',1,1),(10019,'2026-08-17 19:17:53','2026-08-17 19:17:53','analytics','bad_optical_level_rx','optical_rx{iface_type=\"ONU\"} > -10 or optical_rx{iface_type=\"ONU\"} < -28','15m','warning','Signal Level Issues','The RX signal level on ONU {{ $labels.iface_name }}, OLT {{ $labels.ip }} has exceeded the limit - {{ humanize $value }}dBm',1,1),(10020,'2026-04-14 14:49:00','2026-04-14 14:49:00','sensors','sensor_test_alert','device_sensor{name=\"Temperature\"} > 18','10m','info','High temperature','High temp - {{$value}},  on sensor {{$labels.ip}}',1,0),(10021,'2026-04-14 14:49:00','2026-04-14 14:49:00','sensors','sensors_low_battery_level','device_sensor{type=\"analog_line\", name=\"Battery\"}  < 44  ','10m','warning','Low battery level','Battery voltage {{humanize $value}} on sensor {{$labels.ip}} is very low',1,0),(10022,'2026-04-14 14:49:00','2026-04-14 14:49:00','sensors','sensors_no_power_supply','device_sensor{type=\"power_sensor\"} == 0','5m','warning','No power supply','No power on sensor {{ $labels.ip }}',1,0),(10023,'2026-08-17 19:17:53','2026-08-17 19:17:53','links','high_link_utilization','max_over_time(link_utilization_prc[15m]) > 85','15m','warning','High link utilization','Link {{ $labels.src_device_ip }} -> {{ $labels.dest_device_ip }} utilization is too high in one direction - {{ humanize $value }}% ',1,1),(10026,'2026-08-17 19:17:53','2026-08-17 19:17:53','analytics','bad_optical_sfp_rx','optical_rx{iface_type != \"ONU\"} > 5 or optical_rx{iface_type != \"ONU\"} < -15','5m','warning','Bad SFP signal','The RX signal level on SFP {{ $labels.iface_name }}, IP {{ $labels.ip }} has exceeded the limit - {{ humanize $value }}dBm',1,1),(10027,'2026-08-17 19:03:18','2026-08-17 19:03:18','paths','path_down','path_state == 0','2m','critical','Transport path is down','Path {{ $labels.path_name }} ({{ $labels.endpoint_a_name }} -> {{ $labels.endpoint_b_name }}) is down.',1,1),(10028,'2026-08-17 19:03:18','2026-08-17 19:03:18','paths','path_degraded','path_state == 0.5','5m','warning','Transport path is degraded','Path {{ $labels.path_name }} is up but latency on at least one hop is above the configured threshold.',1,1),(10029,'2026-08-17 19:03:18','2026-08-17 19:03:18','paths','path_group_unprotected','path_group_protected == 0 and path_group_up_count > 0','2m','warning','Redundancy lost - group is unprotected','Group {{ $labels.group_key }} still carries traffic but has lost redundancy: {{ $labels.group_key }} has {{ $value }} protected state. A further failure will cause an outage.',1,1),(10030,'2026-08-17 19:03:18','2026-08-17 19:03:18','paths','path_group_outage','path_group_up_count == 0','1m','critical','All paths in group are down','Every path in group {{ $labels.group_key }} is down - the destination is unreachable.',1,1);
/*!40000 ALTER TABLE `c_events_alertmanager_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_links`
--

DROP TABLE IF EXISTS `c_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `src_device_id` int NOT NULL,
  `src_iface_id` int DEFAULT NULL,
  `dest_device_id` int NOT NULL,
  `dest_iface_id` int DEFAULT NULL,
  `source` enum('manual','fdb','lldp') NOT NULL DEFAULT 'manual',
  `params` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_links_device_interfaces_id_fk` (`src_iface_id`),
  KEY `c_links_device_interfaces_id_fk_2` (`dest_iface_id`),
  KEY `c_links_devices_id_fk` (`src_device_id`),
  KEY `c_links_devices_id_fk_2` (`dest_device_id`),
  CONSTRAINT `c_links_device_interfaces_id_fk` FOREIGN KEY (`src_iface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `c_links_device_interfaces_id_fk_2` FOREIGN KEY (`dest_iface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `c_links_devices_id_fk` FOREIGN KEY (`src_device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_links_devices_id_fk_2` FOREIGN KEY (`dest_device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_links`
--

LOCK TABLES `c_links` WRITE;
/*!40000 ALTER TABLE `c_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_macros`
--

DROP TABLE IF EXISTS `c_macros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_macros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `device_model_ids` json NOT NULL,
  `allowed_role_ids` json NOT NULL,
  `display_for` json NOT NULL,
  `parameters` json NOT NULL,
  `template` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `display_output` enum('no','all','last') NOT NULL DEFAULT 'no',
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_macros`
--

LOCK TABLES `c_macros` WRITE;
/*!40000 ALTER TABLE `c_macros` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_macros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_notifications`
--

DROP TABLE IF EXISTS `c_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `send_at` datetime NOT NULL,
  `sent_at` datetime DEFAULT NULL,
  `type` enum('notification','alert','resolved') NOT NULL DEFAULT 'alert',
  `contact_id` int NOT NULL,
  `event_id` int DEFAULT NULL,
  `action_id` int DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `previous_notification_id` int DEFAULT NULL,
  `status` enum('in_process','failed','sent','canceled') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_notifications_events_c_notifications_contacts_id_fk` (`contact_id`),
  KEY `c_notifications_events_c_notifications_events_id_fk` (`previous_notification_id`),
  KEY `c_notifications_created_at_index` (`created_at`),
  KEY `c_notifications_send_at_index` (`send_at`),
  KEY `c_notifications_status_index` (`status`),
  KEY `c_notifications_type_index` (`type`),
  KEY `c_notifications_event_id_index` (`event_id`),
  CONSTRAINT `c_notifications_events_c_notifications_contacts_id_fk` FOREIGN KEY (`contact_id`) REFERENCES `c_notifications_contacts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_notifications_events_c_notifications_events_id_fk` FOREIGN KEY (`previous_notification_id`) REFERENCES `c_notifications` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_notifications`
--

LOCK TABLES `c_notifications` WRITE;
/*!40000 ALTER TABLE `c_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_notifications_actions_config`
--

DROP TABLE IF EXISTS `c_notifications_actions_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_notifications_actions_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `action_name` varchar(150) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `send_on_status_failed` tinyint NOT NULL DEFAULT '1',
  `send_on_status_success` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_notifications_actions_config_action_name_uindex` (`action_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_notifications_actions_config`
--

LOCK TABLES `c_notifications_actions_config` WRITE;
/*!40000 ALTER TABLE `c_notifications_actions_config` DISABLE KEYS */;
INSERT INTO `c_notifications_actions_config` VALUES (1,'2022-07-23 23:53:11','huawei_olts:onu_info',0,1,1),(2,'2022-07-23 23:53:11','huawei_olts:interface_info',0,1,1),(3,'2022-07-22 16:10:21','device-access:edited',1,1,1),(4,'2022-07-23 14:53:09','c_data_interfaces:interface_info',0,1,1),(5,'2022-07-23 14:53:09','c_data_interfaces:onu_info',0,1,1),(6,'2022-07-23 14:53:09','device-access:added',1,1,1),(7,'2022-07-23 14:53:09','device:added',1,1,1),(8,'2022-07-23 14:53:09','device:deleted',1,1,1),(9,'2022-07-23 14:53:09','device:updated',1,1,1),(10,'2022-07-23 14:53:09','notifications:actions-config-updated',1,1,1),(11,'2022-07-23 14:53:09','notifications:channel-updated',1,1,1),(12,'2022-07-23 14:53:09','user:logged_in',1,1,1),(51,'2022-07-23 14:53:09','user:logged_out',1,1,1),(52,'2022-07-23 14:53:09','zte_unregistered_onts:template_updated',1,1,1);
/*!40000 ALTER TABLE `c_notifications_actions_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `c_notify_ignore_devices_actions` BEFORE DELETE ON `c_notifications_actions_config` FOR EACH ROW BEGIN
    DELETE FROM c_notifications_ignore_devices WHERE type = 'action' and notification_id = OLD.id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `c_notifications_contacts`
--

DROP TABLE IF EXISTS `c_notifications_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_notifications_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int NOT NULL,
  `type` enum('EMAIL','PHONE','PHONE_FOR_TELEGRAM','TELEGRAM_ID') DEFAULT NULL,
  `value` varchar(150) DEFAULT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `description` varchar(200) DEFAULT '',
  `params` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_notifications_contacts_type_value_user_id_uindex` (`type`,`value`,`user_id`),
  KEY `c_notifications_contacts_users_id_fk` (`user_id`),
  CONSTRAINT `c_notifications_contacts_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_notifications_contacts`
--

LOCK TABLES `c_notifications_contacts` WRITE;
/*!40000 ALTER TABLE `c_notifications_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_notifications_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_notifications_events_config`
--

DROP TABLE IF EXISTS `c_notifications_events_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_notifications_events_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `delay_before_send` int NOT NULL DEFAULT '0',
  `send_resolved` tinyint NOT NULL DEFAULT '1',
  `check_uplink` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_notifications_events_config_event_name_uindex` (`event_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_notifications_events_config`
--

LOCK TABLES `c_notifications_events_config` WRITE;
/*!40000 ALTER TABLE `c_notifications_events_config` DISABLE KEYS */;
INSERT INTO `c_notifications_events_config` VALUES (1,1,'2022-07-22 15:33:51','rx_signal_deteriorated',0,1,0),(2,1,'2022-07-22 15:33:51','pinger_host_down',60,1,0),(3,1,'2022-07-22 15:33:51','mass_interfaces_down',0,1,0),(4,1,'2022-07-22 15:33:51','interface_is_down',0,1,0),(10000,1,'2026-04-14 14:49:03','bgp_session_restarted',0,1,0),(10001,1,'2026-04-14 14:49:03','bgp_session_down',0,1,0),(10002,1,'2026-04-14 14:49:03','pon_box_status',0,1,0);
/*!40000 ALTER TABLE `c_notifications_events_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb3 */ ;
/*!50003 SET character_set_results = utf8mb3 */ ;
/*!50003 SET collation_connection  = utf8mb3_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `c_notify_ignore_devices_events` BEFORE DELETE ON `c_notifications_events_config` FOR EACH ROW BEGIN
    DELETE FROM c_notifications_ignore_devices WHERE type = 'event' and notification_id = OLD.id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `c_notifications_ignore_devices`
--

DROP TABLE IF EXISTS `c_notifications_ignore_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_notifications_ignore_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `device_id` int NOT NULL,
  `notification_id` int NOT NULL,
  `type` enum('action','event') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_notifications_ignore_devices_notification_id_type_uindex` (`notification_id`,`type`,`device_id`),
  KEY `c_notifications_ignore_devices_devices_id_fk` (`device_id`),
  KEY `c_notifications_ignore_devices_type_index` (`type`),
  CONSTRAINT `c_notifications_ignore_devices_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_notifications_ignore_devices`
--

LOCK TABLES `c_notifications_ignore_devices` WRITE;
/*!40000 ALTER TABLE `c_notifications_ignore_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_notifications_ignore_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_onts_registration_macros`
--

DROP TABLE IF EXISTS `c_onts_registration_macros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_onts_registration_macros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(200) NOT NULL,
  `device_model_ids` json NOT NULL,
  `parameters` json NOT NULL,
  `template` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_onts_registration_macros`
--

LOCK TABLES `c_onts_registration_macros` WRITE;
/*!40000 ALTER TABLE `c_onts_registration_macros` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_onts_registration_macros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_path_segments`
--

DROP TABLE IF EXISTS `c_path_segments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_path_segments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `path_id` int NOT NULL,
  `position` int NOT NULL,
  `link_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_path_segments_uniq_position` (`path_id`,`position`),
  KEY `c_path_segments_c_links_id_fk` (`link_id`),
  CONSTRAINT `c_path_segments_c_links_id_fk` FOREIGN KEY (`link_id`) REFERENCES `c_links` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_path_segments_c_paths_id_fk` FOREIGN KEY (`path_id`) REFERENCES `c_paths` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_path_segments`
--

LOCK TABLES `c_path_segments` WRITE;
/*!40000 ALTER TABLE `c_path_segments` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_path_segments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_path_states`
--

DROP TABLE IF EXISTS `c_path_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_path_states` (
  `path_id` int NOT NULL,
  `state` enum('up','degraded','down','unknown') NOT NULL DEFAULT 'unknown',
  `last_change` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `detail` json DEFAULT NULL,
  PRIMARY KEY (`path_id`),
  CONSTRAINT `c_path_states_c_paths_id_fk` FOREIGN KEY (`path_id`) REFERENCES `c_paths` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_path_states`
--

LOCK TABLES `c_path_states` WRITE;
/*!40000 ALTER TABLE `c_path_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_path_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_paths`
--

DROP TABLE IF EXISTS `c_paths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_paths` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(255) NOT NULL,
  `group_key` varchar(190) DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '100',
  `endpoint_a_id` int NOT NULL,
  `endpoint_b_id` int NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `params` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_paths_devices_id_fk` (`endpoint_a_id`),
  KEY `c_paths_devices_id_fk_2` (`endpoint_b_id`),
  KEY `c_paths_group_key_index` (`group_key`),
  CONSTRAINT `c_paths_devices_id_fk` FOREIGN KEY (`endpoint_a_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_paths_devices_id_fk_2` FOREIGN KEY (`endpoint_b_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_paths`
--

LOCK TABLES `c_paths` WRITE;
/*!40000 ALTER TABLE `c_paths` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_paths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pinger_down_logs`
--

DROP TABLE IF EXISTS `c_pinger_down_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pinger_down_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start` datetime NOT NULL,
  `stop` datetime DEFAULT NULL,
  `device_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `c_pinger_down_logs_devices_id_fk` (`device_id`),
  CONSTRAINT `c_pinger_down_logs_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pinger_down_logs`
--

LOCK TABLES `c_pinger_down_logs` WRITE;
/*!40000 ALTER TABLE `c_pinger_down_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_pinger_down_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pinger_statuses`
--

DROP TABLE IF EXISTS `c_pinger_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pinger_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` int NOT NULL,
  `last_change` datetime NOT NULL,
  `latency` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `c_pinger_statuses_device_id_uindex` (`device_id`),
  CONSTRAINT `c_pinger_statuses_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pinger_statuses`
--

LOCK TABLES `c_pinger_statuses` WRITE;
/*!40000 ALTER TABLE `c_pinger_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_pinger_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pon_boxes_mon_interfaces`
--

DROP TABLE IF EXISTS `c_pon_boxes_mon_interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pon_boxes_mon_interfaces` (
  `id` int NOT NULL AUTO_INCREMENT,
  `interface_id` int NOT NULL,
  `object_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `c_pon_boxes_mon_interfaces_c_pon_boxes_objects_id_fk` (`object_id`),
  KEY `c_pon_boxes_mon_interfaces_device_interfaces_id_fk` (`interface_id`),
  CONSTRAINT `c_pon_boxes_mon_interfaces_c_pon_boxes_objects_id_fk` FOREIGN KEY (`object_id`) REFERENCES `c_pon_boxes_objects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_pon_boxes_mon_interfaces_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pon_boxes_mon_interfaces`
--

LOCK TABLES `c_pon_boxes_mon_interfaces` WRITE;
/*!40000 ALTER TABLE `c_pon_boxes_mon_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_pon_boxes_mon_interfaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pon_boxes_object_types`
--

DROP TABLE IF EXISTS `c_pon_boxes_object_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pon_boxes_object_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `type` enum('line','box') NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text,
  `style` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pon_boxes_object_types`
--

LOCK TABLES `c_pon_boxes_object_types` WRITE;
/*!40000 ALTER TABLE `c_pon_boxes_object_types` DISABLE KEYS */;
INSERT INTO `c_pon_boxes_object_types` VALUES (1,'2022-09-27 20:30:44','box','1x12','','{\"fill\": \"#754a00\", \"width\": 28, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(4,'2022-09-28 21:41:26','line','FinMark UT002-SM-16S-1kN','Оптичний кабель FinMark UT002-SM-16S-1kN, 2 волокна','{\"color\": \"#51b6bd\", \"weight\": 3}'),(5,'2022-10-04 21:39:32','box','1x8','','{\"fill\": \"#00756d\", \"width\": 26, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(6,'2022-10-04 21:40:01','box','1x6','','{\"fill\": \"#f0fd3f\", \"width\": 24, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(7,'2022-10-04 21:40:24','box','1x4','','{\"fill\": \"#275db4\", \"width\": 21, \"stroke\": \"#8d8b8b\", \"strokeWidth\": 2}'),(10,'2022-10-05 22:47:24','line','FinMark UT001-SM-16S-1kN','Оптичний кабель FinMark UT001-SM-16S-1kN, 1 волокно','{\"color\": \"#51b6bd\", \"weight\": 2}'),(11,'2022-10-07 16:01:42','box','1x3','','{\"fill\": \"#624b4b\", \"width\": 20, \"stroke\": \"#091625\", \"strokeWidth\": 2}'),(12,'2022-10-07 19:32:56','box','1x2','','{\"fill\": \"#febebe\", \"width\": 19, \"stroke\": \"#000000\", \"strokeWidth\": 2}'),(14,'2022-12-09 21:48:34','box','1x16','','{\"fill\": \"#f820e6\", \"width\": 30, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(15,'2022-12-09 21:49:01','box','1x32','','{\"fill\": \"#a3ffed\", \"width\": 32, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(16,'2022-12-09 21:49:25','box','1x64','','{\"fill\": \"#7ec88b\", \"width\": 35, \"stroke\": \"#91c3ff\", \"strokeWidth\": 3}'),(17,'2022-12-09 21:52:37','line','FinMark UT004-SM-16S-1kN','Оптичний кабель FinMark UT004-SM-16S-1kN, 4 волокна','{\"color\": \"#51b6bd\", \"weight\": 4}'),(18,'2022-12-09 21:54:44','line','FinMark UT008-SM-15','Оптичний кабель FinMark UT008-SM-15, 8 волокон','{\"color\": \"#51b6bd\", \"weight\": 8}'),(19,'2022-12-09 21:55:32','line','ОКТ-Д (0,5)П-1Е1','Оптичний кабель ОКТ-Д (0,5)П-1Е1 1 волокно (колишній EcoLight)','{\"color\": \"#dd925f\", \"weight\": 2}'),(20,'2022-12-09 21:56:09','line','ОКТ-Д (0,5)П-2Е1','Оптичний кабель ОКТ-Д (0,5)П-2Е1 2 волокна (колишній EcoLight)','{\"color\": \"#dd925f\", \"weight\": 3}');
/*!40000 ALTER TABLE `c_pon_boxes_object_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pon_boxes_objects`
--

DROP TABLE IF EXISTS `c_pon_boxes_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pon_boxes_objects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `name` varchar(150) NOT NULL,
  `template_id` int NOT NULL,
  `type_id` int NOT NULL,
  `coordinates` json NOT NULL,
  `status` enum('unknown','up','down') DEFAULT 'unknown',
  PRIMARY KEY (`id`),
  KEY `c_pon_boxes_objects_c_pon_boxes_object_types_id_fk` (`type_id`),
  KEY `c_pon_boxes_objects_c_pon_boxes_template_bindings_id_fk` (`template_id`),
  CONSTRAINT `c_pon_boxes_objects_c_pon_boxes_object_types_id_fk` FOREIGN KEY (`type_id`) REFERENCES `c_pon_boxes_object_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `c_pon_boxes_objects_c_pon_boxes_template_bindings_id_fk` FOREIGN KEY (`template_id`) REFERENCES `c_pon_boxes_template_bindings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pon_boxes_objects`
--

LOCK TABLES `c_pon_boxes_objects` WRITE;
/*!40000 ALTER TABLE `c_pon_boxes_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_pon_boxes_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_pon_boxes_template_bindings`
--

DROP TABLE IF EXISTS `c_pon_boxes_template_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_pon_boxes_template_bindings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `description` text,
  `interface_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_pon_boxes_template_bindings_device_interfaces_id_fk` (`interface_id`),
  CONSTRAINT `c_pon_boxes_template_bindings_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_pon_boxes_template_bindings`
--

LOCK TABLES `c_pon_boxes_template_bindings` WRITE;
/*!40000 ALTER TABLE `c_pon_boxes_template_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_pon_boxes_template_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_trap_logs`
--

DROP TABLE IF EXISTS `c_trap_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `c_trap_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `device_id` int NOT NULL,
  `interface_id` int DEFAULT NULL,
  `object` varchar(100) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `modules` json DEFAULT NULL,
  `parsed` json DEFAULT NULL,
  `raw` json DEFAULT NULL,
  `errors` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `c_trap_logs_device_interfaces_id_fk` (`interface_id`),
  KEY `c_trap_logs_devices_id_fk` (`device_id`),
  KEY `c_trap_logs_created_at_index` (`created_at` DESC),
  KEY `c_trap_logs_name_index` (`name`),
  KEY `c_trap_logs_object_index` (`object`),
  CONSTRAINT `c_trap_logs_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE,
  CONSTRAINT `c_trap_logs_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Log SNMP traps from devices';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_trap_logs`
--

LOCK TABLES `c_trap_logs` WRITE;
/*!40000 ALTER TABLE `c_trap_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `c_trap_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_accesses`
--

DROP TABLE IF EXISTS `device_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_accesses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `public_community` varchar(255) NOT NULL,
  `private_community` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `params` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_accesses_name_uindex` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_accesses`
--

LOCK TABLES `device_accesses` WRITE;
/*!40000 ALTER TABLE `device_accesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_accesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_groups`
--

DROP TABLE IF EXISTS `device_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_groups`
--

LOCK TABLES `device_groups` WRITE;
/*!40000 ALTER TABLE `device_groups` DISABLE KEYS */;
INSERT INTO `device_groups` VALUES (-1,'2026-04-14 14:48:40','SYSTEM_GROUP','DEFAULT_SYSTEM_GROUP');
/*!40000 ALTER TABLE `device_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_interfaces`
--

DROP TABLE IF EXISTS `device_interfaces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_interfaces` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `device_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` enum('FE','GE','TGE','ETH','PON','SFP','ONU','UNI','1G-SFP','10G-SFP','UNKNOWN','VLAN','LACP','BRIDGE','Loopback','Virtual','IP','EPON') DEFAULT NULL,
  `params` json DEFAULT NULL,
  `billing_link` varchar(255) DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  `agreement` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `bind_key` varchar(50) NOT NULL,
  `updated_at` datetime NOT NULL,
  `status` enum('Up','Down','Disabled','Online','Offline','Unknown','PowerOff','LOS') DEFAULT NULL,
  `poll_enabled` tinyint NOT NULL DEFAULT '1',
  `parent_bind_key` varchar(50) DEFAULT NULL,
  `coordinates` json DEFAULT NULL,
  `comment` text,
  `status_changed` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_interfaces_device_id_bind_key_uindex` (`device_id`,`bind_key`),
  KEY `device_interfaces_parent_bind_key_index` (`parent_bind_key`),
  CONSTRAINT `device_interfaces_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_interfaces`
--

LOCK TABLES `device_interfaces` WRITE;
/*!40000 ALTER TABLE `device_interfaces` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_interfaces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_interfaces_history`
--

DROP TABLE IF EXISTS `device_interfaces_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_interfaces_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `interface_id` int NOT NULL,
  `up` datetime NOT NULL,
  `down` datetime DEFAULT NULL,
  `down_reason` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_interfaces_history_device_interfaces_id_fk` (`interface_id`),
  CONSTRAINT `device_interfaces_history_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_interfaces_history`
--

LOCK TABLES `device_interfaces_history` WRITE;
/*!40000 ALTER TABLE `device_interfaces_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_interfaces_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_interfaces_tags`
--

DROP TABLE IF EXISTS `device_interfaces_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_interfaces_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `interface_id` int NOT NULL,
  `type` enum('FAVORITE','TAG') NOT NULL DEFAULT 'FAVORITE',
  `value` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_interfaces_tags_interface_id_value_uindex` (`interface_id`,`value`),
  KEY `device_interfaces_tags_type_index` (`type`),
  CONSTRAINT `device_interfaces_tags_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_interfaces_tags`
--

LOCK TABLES `device_interfaces_tags` WRITE;
/*!40000 ALTER TABLE `device_interfaces_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_interfaces_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_models`
--

DROP TABLE IF EXISTS `device_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(150) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `params` json DEFAULT NULL,
  `vendor` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `type` enum('SWITCH','OLT','ONU','ROUTER','SENSOR','UNKNOWN','SWITCHL3','ROUTEROS') NOT NULL DEFAULT 'SWITCH',
  `icon` varchar(255) DEFAULT NULL,
  `controller` varchar(200) DEFAULT NULL,
  `pollers` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_models_key_uindex` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_models`
--

LOCK TABLES `device_models` WRITE;
/*!40000 ALTER TABLE `device_models` DISABLE KEYS */;
INSERT INTO `device_models` VALUES (2,'icmp_power_control','ICMP power control','{}','Unknown','Unknown','UNKNOWN','/upload/icons/high_voltage.png',NULL,'{}'),(3,'default_icmp','ICMP pinged device','{}','Unknown','Unknown','UNKNOWN','/upload/icons/router.png',NULL,'{}'),(4,'bdcom_p3310','BDcom P3310','{\"show_optical_info_from_history\": true}','BDcom','P3310','OLT','/upload/icons/bdcom_p3310.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(5,'bdcom_p3310b','BDcom P3310В','{\"show_optical_info_from_history\": true}','BDcom','P3310B','OLT','/upload/icons/bdcom_p3310.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(6,'bdcom_p3310c','BDcom P3310C','{\"show_optical_info_from_history\": true}','BDcom','P3310C','OLT','/upload/icons/bdcom_p3310.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(7,'bdcom_p3310d','BDcom P3310D','{\"show_optical_info_from_history\": true}','BDcom','P3310D','OLT','/upload/icons/bdcom_p3310.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(8,'bdcom_p3608b','BDCOM P3608B','{\"show_optical_info_from_history\": true}','BDcom','P3608B','OLT','/upload/icons/bdcom_p3608b.webp','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(9,'bdcom_p3612_2te','BDCOM P3612-2TE','{\"show_optical_info_from_history\": true}','BDcom','P3612-2TE','OLT','/upload/icons/bdcom_p3612_2te.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(10,'bdcom_p3616_2te','BDCOM P3616-2TE','{\"show_optical_info_from_history\": true}','BDcom','P3616-2TE','OLT','/upload/icons/bdcom_p3616_2te.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(11,'c_data_fd1204sn','C-Data FD1204SN','{\"show_optical_info_from_history\": true}','C-Data','FD1204SN','OLT','/upload/icons/fd1204sn.jpeg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(12,'c_data_fd1616','C-Data FD1616','{\"show_optical_info_from_history\": true}','C-Data','FD1616','OLT','/upload/icons/fd-1616sn-r1.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(13,'c_data_fd1208s','C-Data FD1208S','{\"show_optical_info_from_history\": true}','C-Data','FD1208S','OLT','/upload/icons/fd-1208s-r1.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(14,'c_data_fd1104sn','C-Data FD1104SN','{\"show_optical_info_from_history\": true}','C-Data','FD1104SN','OLT','/upload/icons/fd1104sn.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(15,'c_data_fd1108s','C-Data FD1108S','{\"show_optical_info_from_history\": true}','C-Data','FD1108S','OLT','/upload/icons/fd1108s.webp','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(16,'c_data_fd1216s_r1','C-Data FD1216S','{\"show_optical_info_from_history\": true}','C-Data','FD1216S','OLT','/upload/icons/c_data_fd1216s_r1.webp','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(17,'c_data_fd1608','C-Data FD1608','{\"show_optical_info_from_history\": true}','C-Data','FD1608','OLT','/upload/icons/fd-1608sn.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(18,'huawei_ma5603t','Huawei MA5603T','{\"show_optical_info_from_history\": true}','Huawei','MA5603T','OLT','/upload/icons/huawei_ma5603t.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(19,'huawei_ma5608t','Huawei MA5608T','{\"show_optical_info_from_history\": true}','Huawei','MA5608T','OLT','/upload/icons/huawei_ma5608t.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(20,'huawei_ma5683t','Huawei MA5683T','{\"show_optical_info_from_history\": true}','Huawei','MA5683T','OLT','/upload/icons/huawei_ma5603t.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(21,'huawei_ma5680t','Huawei MA5680T','{\"show_optical_info_from_history\": true}','Huawei','MA5680T','OLT','/upload/icons/huawei_ma5680.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(22,'v_solution_v1600d8','V-Solution V1600D8','{\"show_optical_info_from_history\": true}','V-Solution','V1600D8','OLT','/upload/icons/v_sol_v1600d8.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(23,'v_solution_v1600d16','V-Solution V1600D16','{\"show_optical_info_from_history\": true}','V-Solution','V1600D16','OLT','/upload/icons/v_sol_v1600d16.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(24,'v_solution_v1600d','V-Sol OLT V1600 series','{\"show_optical_info_from_history\": true}','V-Solution','V1600D8','OLT','/upload/icons/v-sol-general.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(25,'zte_c320','ZTE C320','{\"show_optical_info_from_history\": true}','ZTE','C320','OLT','/upload/icons/1.jpeg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(26,'zte_c320_fw_1_2','ZTE C320 (FW 1.2)','{\"show_optical_info_from_history\": true}','ZTE','C320','OLT','/upload/icons/1.jpeg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(27,'zte_c300','ZTE C300','{\"show_optical_info_from_history\": true}','ZTE','C300','OLT','/upload/icons/zte_c300.webp','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(28,'zte_c220','ZTE C220','{\"show_optical_info_from_history\": true}','ZTE','C220','OLT','/upload/icons/zte_c220.jpg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(29,'zte_c300_fw_1_2','ZTE C300 (FW 1.2)','{\"show_optical_info_from_history\": true}','ZTE','C300','OLT','/upload/icons/zte_c300.webp','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(30,'bdcom_gp3600_series','BDCOM GP3600 series','{\"show_optical_info_from_history\": true}','BDcom','GP3600 series','OLT','/upload/icons/bdcom_logo.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(31,'bdcom_gp3600_04','BDCOM GP3600-04','{\"show_optical_info_from_history\": true}','BDcom','GP3600-04','OLT','/upload/icons/bdcom_gp3600_04.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(32,'bdcom_gp3600_08','BDCOM GP3600-08','{\"show_optical_info_from_history\": true}','BDcom','GP3600-08','OLT','/upload/icons/bdcom_gp3600_08b.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(33,'bdcom_gp3600_16','BDCOM GP3600-16','{\"show_optical_info_from_history\": true}','BDcom','GP3600-16','OLT','/upload/icons/bdom_gp3600_16b.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(34,'gcom_el5610_series','GCOM EL5610 series','{\"show_optical_info_from_history\": true}','GCOM','EL5610 series','OLT','/upload/icons/gcom_logo.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(35,'gcom_el5610_04p','GCOM EL5610-04P','{\"show_optical_info_from_history\": true}','GCOM','EL5610-04P','OLT','/upload/icons/gcom_el5610_04.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(36,'gcom_el5610_08p','GCOM EL5610-08P','{\"show_optical_info_from_history\": true}','GCOM','EL5610-08P','OLT','/upload/icons/gcom_el5610_08.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(37,'gcom_el5610_16p','GCOM EL5610-16P','{\"show_optical_info_from_history\": true}','GCOM','EL5610-16P','OLT','/upload/icons/gcom_el5610_16.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(38,'zte_zxpon_olt_series','ZTE C600 series','{\"show_optical_info_from_history\": true}','ZTE','C600 series','OLT','/upload/icons/ZTE_logo.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(39,'zte_c600_fw_12','ZTE C600 (FW 1.2)','{\"show_optical_info_from_history\": true}','ZTE','C600','OLT','/upload/icons/zte_c600.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(40,'zte_c610_fw_12','ZTE C610 (FW 1.2)','{\"show_optical_info_from_history\": true}','ZTE','C610','OLT','/upload/icons/zte_c610.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"cards_status\": 120, \"sys_resources\": 120, \"interfaces_list\": 300, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(41,'huawei_smart_ax','Huawei SmartAX OLT','{\"show_optical_info_from_history\": true}','Huawei','SmartAX OLT','OLT','/upload/icons/huawei.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 120, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(42,'bdcom_p36xx_series','BDcom P36xx series','{\"show_optical_info_from_history\": true}','BDcom','P36xx series','OLT','/upload/icons/bdcom_logo.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 120, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(43,'v_solution_v1600g','V-Solution V1600G series','{\"show_optical_info_from_history\": true}','V-Solution','V1600G','OLT','/upload/icons/v-sol-general.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(44,'v_solution_v1600g1b','V-Solution V1600G1B','{\"show_optical_info_from_history\": true}','V-Solution','V1600G1B','OLT','/upload/icons/v-sol-general.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 900, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 1800, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(45,'gcom_el5610_series_old','GCOM EPON series (OLD)','{\"show_optical_info_from_history\": true}','GCOM','EPON series (OLD)','OLT','/upload/icons/gcom_logo.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(46,'c_data_fd1608_fw3','C-Data FD1608 (FW 3)','{\"show_optical_info_from_history\": true}','C-Data','FD1608 (FW 3)','OLT','/upload/icons/fd-1608sn.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(47,'c_data_fd1616_fw3','C-Data FD1616 (FW 3)','{\"show_optical_info_from_history\": true}','C-Data','FD1616 (FW 3)','OLT','/upload/icons/fd-1616sn-r1.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(48,'c_data_fd1604','C-Data FD1604','{\"show_optical_info_from_history\": true}','C-Data','FD1604','OLT','/upload/icons/fd1604.jpeg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(49,'c_data_fd1604_fw3','C-Data FD1604 (FW 3)','{\"show_optical_info_from_history\": true}','C-Data','FD1604 (FW 3)','OLT','/upload/icons/fd1604.jpeg','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(50,'c_data_fd1601','C-Data FD1601','{\"show_optical_info_from_history\": true}','C-Data','FD1601','OLT','/upload/icons/cdata.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180}'),(51,'c_data_fd1601_fw3','C-Data FD1601 (FW 3)','{\"show_optical_info_from_history\": true}','C-Data','FD1601 (FW 3)','OLT','/upload/icons/cdata.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180, \"sfp_optical_strength\": 300}'),(52,'mikrotik_ccr1036','Mikrotik CCR1036','{\"collect_interval\": 300}','Mikrotik','CCR1036','ROUTEROS','/upload/icons/mikrotik_ccr1036.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(53,'mikrotik_ccr1009','Mikrotik CCR1009','{\"collect_interval\": 300}','Mikrotik','CCR1009','ROUTEROS','/upload/icons/mikrotik_ccr1009.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(54,'mikrotik_ccr1016','Mikrotik CCR1016','{\"collect_interval\": 300}','Mikrotik','CCR1016','ROUTEROS','/upload/icons/mikrotik_ccr1016.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(55,'mikrotik_rb4011','Mikrotik RB4011','{\"collect_interval\": 300}','Mikrotik','RB4011','ROUTEROS','/upload/icons/mikrotik_rb4011.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(56,'mikrotik_rb750gr3','Mikrotik RB750Gr3','{\"collect_interval\": 300}','Mikrotik','RB750Gr3','ROUTEROS','/upload/icons/mikrotik_rb750gr3.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(57,'mikrotik_rb2011uias_2hnd','Mikrotik RB2011UiAS-2HnD','{\"collect_interval\": 300}','Mikrotik','RB2011UiAS-2HnD','ROUTEROS','/upload/icons/mikrotik_rb2011uias_2hnd.png','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(58,'mikrotik_crs317_1g_16s','Mikrotik CRS317-1G-16S+','{\"collect_interval\": 300}','Mikrotik','CRS317-1G-16S+','SWITCH','/upload/icons/mikrotik_crs317_1g_16s.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(59,'mikrotik_crs328_4c_20s_4s','Mikrotik CRS328-4C-20S-4S+','{\"collect_interval\": 300}','Mikrotik','CRS328-4C-20S-4S+','SWITCH','/upload/icons/mikrotik_crs328_4c_20s_4s.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(60,'mikrotik_router_os','Mikrotik RouterOS','{}','Mikrotik','RouterOS','ROUTEROS','/upload/icons/mikrotik-routeros.jpeg','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(61,'mikrotik_rb3011uias','Mikrotik RB3011UiAS','{}','Mikrotik','RB3011UiAS','ROUTEROS','/upload/icons/mikrotik-routeros.jpeg','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(62,'mikrotik_rb750','Mikrotik RB750','{}','Mikrotik','RB750','ROUTEROS','/upload/icons/mikrotik-routeros.jpeg','\\WCC\\RouterOS\\Controllers\\Controller','{\"system\": 300, \"counters\": 60, \"arp_table\": 600, \"bgp_sessions\": 300, \"sys_resources\": 180, \"interfaces_list\": 300, \"interfaces_status\": 60, \"sfp_optical_strength\": 300}'),(63,'dlink_des_1210_28_me_b2','D-Link DES-1210-28/ME/B2','{}','D-Link','DES-1210-28/ME/B2','SWITCH','/upload/icons/des-1210-28-me.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(64,'dlink_des_1228_me','D-Link DES-1228/ME','{}','D-Link','DES-1228/ME','SWITCH','/upload/icons/des-1228-me.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(65,'dlink_des_3028','D-Link DES-3028','{}','D-Link','DES-3028','SWITCH','/upload/icons/des-3028.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(66,'dlink_des_3028g','D-Link DES-3028G','{}','D-Link','DES-3028G','SWITCH','/upload/icons/DES-3028G.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(67,'dlink_des_3052g','D-Link DES-3052','{}','D-Link','DES-3052','SWITCH','/upload/icons/DES-3052.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(68,'dlink_des_3200_10_a1','D-Link DES-3200-10/A1','{}','D-Link','DES-3200-10/A1','SWITCH','/upload/icons/DES-3200-10.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(69,'dlink_des_3200_10_c1','D-Link DES-3200-10/C1','{}','D-Link','DES-3200-10/C1','SWITCH','/upload/icons/DES-3200-10-C1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(70,'dlink_des_3200_18_a1','D-Link DES-3200-18/A1','{}','D-Link','DES-3200-18/A1','SWITCH','/upload/icons/DES-3200-18_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(71,'dlink_des_3200_18_c1','D-Link DES-3200-18/C1','{}','D-Link','DES-3200-18/C1','SWITCH','/upload/icons/DES-3200-18_C1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(72,'dlink_des_3200_26_a1','D-Link DES-3200-26/A1','{}','D-Link','DES-3200-26/A1','SWITCH','/upload/icons/DES-3200-26_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(73,'dlink_des_3200_26_c1','D-Link DES-3200-26/C1','{}','D-Link','DES-3200-26/C1','SWITCH','/upload/icons/DES-3200-26_C1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(74,'dlink_des_3200_28_a1','D-Link DES-3200-28/A1','{}','D-Link','DES-3200-28/A1','SWITCH','/upload/icons/DES-3200-28_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(75,'dlink_des_3200_28_c1','D-Link DES-3200-28/C1','{}','D-Link','DES-3200-28/C1','SWITCH','/upload/icons/DES-3200-28_C1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(76,'dlink_des_3200_28f_a1','D-Link DES-3200-28F/A1','{}','D-Link','DES-3200-28F/A1','SWITCH','/upload/icons/DES-3200-28F_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(77,'dlink_des_3200_28f_c1','D-Link DES-3200-28F/C1','{}','D-Link','DES-3200-28F/C1','SWITCH','/upload/icons/DES-3200-28F_C1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(78,'dlink_des_3526','D-Link DES-3526','{}','D-Link','DES-3526','SWITCH','/upload/icons/DES-3526.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(79,'dlink_dgs_1100_06_me_a1','D-Link DGS-1100-06/ME/A1','{}','D-Link','DGS-1100-06/ME/A1','SWITCH','/upload/icons/DGS-1100-06ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(80,'dlink_dgs_1100_10_me_a1','D-Link DGS-1100-10/ME/A1','{}','D-Link','DGS-1100-10/ME/A1','SWITCH','/upload/icons/DGS-1100-10ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(81,'dlink_dgs_1210_10_me_a1','D-Link DGS-1210-10/ME/A1','{}','D-Link','DGS-1210-10/ME/A1','SWITCH','/upload/icons/DGS-1210-10ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(82,'dlink_dgs_1210_20_me_a1','D-Link DGS-1210-20/ME/A1','{}','D-Link','DGS-1210-20/ME/A1','SWITCH','/upload/icons/DGS-1210-20ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(83,'dlink_dgs_1210_20_me_b1','D-Link DGS-1210-20/ME/B1','{}','D-Link','DGS-1210-20/ME/B1','SWITCH','/upload/icons/DGS-1210-20ME_B1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(84,'dlink_dgs_1210_28_me_a1','D-Link DGS-1210-28/ME/A1','{}','D-Link','DGS-1210-28/ME/A1','SWITCH','/upload/icons/DGS-1210-28ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(85,'dlink_dgs_1210_28_me_a2','D-Link DGS-1210-28/ME/A2','{}','D-Link','DGS-1210-28/ME/A2','SWITCH','/upload/icons/DGS-1210-28ME_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(86,'dlink_dgs_1210_28_me_b1','D-Link DGS-1210-28/ME/B1','{}','D-Link','DGS-1210-28/ME/B1','SWITCH','/upload/icons/DGS-1210-28ME_B1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(87,'dlink_dgs_1210_28xs_me_b1','D-Link DGS-1210-28XS/ME/B1','{}','D-Link','DGS-1210-28XS/ME/B1','SWITCH','/upload/icons/DGS-1210-28XSME_B1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(88,'dlink_dgs_3000_26tc_a1','D-Link DGS-3000-26TC/A1','{}','D-Link','DGS-3000-26TC/A1','SWITCH','/upload/icons/DGS-3000-26TC_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(89,'dlink_dgs_3000_28l_b1','D-Link DGS-3000-28L/B1','{}','D-Link','DGS-3000-28L/B1','SWITCH','/upload/icons/DGS-3000-28L_B1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(90,'dlink_dgs_3420_28sc_b1','D-link DGS-3420-28SC','{}','D-Link','DGS-3420-28SC','SWITCH','/upload/icons/d-link_dgs-3420-28sc.webp','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(91,'dlink_dgs_3420_26sc_b1','D-link DGS-3420-26SC','{}','D-Link','DGS-3420-26SC','SWITCH','/upload/icons/DGS-3420-26SC_Front.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(92,'dlink_dgs_3120_24sc_a2','D-link DGS-3120-24SC/A2','{}','D-Link','DGS-3120-24SC/A2','SWITCH','/upload/icons/DGS-3120-24SC_A1.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(93,'dlink_dgs_3100_24tg','D-Link DGS-3100-24TG','{}','D-Link','DGS-3000-24TG','SWITCH','/upload/icons/DGS-3100-24TG.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(94,'edgecore_ecs4120_28f','Edge-core ECS4120-28F','{}','Edge-core','ECS4120-28F','SWITCH','/upload/icons/edgecore_ecs4120_28f.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(95,'edgecore_ecs4120_28fv2','Edge-core ECS4120-28Fv2','{}','Edge-core','ECS4120-28Fv2','SWITCH','/upload/icons/edgecore_ecs4120_28fv2.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(96,'edgecore_es3528m','Edge-core ES3528M','{}','Edge-core','ES3528M','SWITCH','/upload/icons/edgecore_es3528m.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(97,'edgecore_es3510ma_v2','Edge-core ES3510MAv2','{}','Edge-core','ES3510MAv2','SWITCH','/upload/icons/edgecore_es3510ma.jpeg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(98,'edgecore_es3510','Edge-core ES3510','{}','Edge-core','ES3510','SWITCH','/upload/icons/edgecore_es3510.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(99,'edgecore_es3552m','Edge-core ES3552M','{}','Edge-core','ES3552M','SWITCH','/upload/icons/edgecore_es3552m.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(100,'edgecore_ecs4510_28f','Edge-core ECS4510-28F','{}','Edge-core','ECS4510-28F','SWITCH','/upload/icons/edgecore_ecs4510_28f.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(101,'edgecore_ecs3510_28t','Edge-core ECS3510-28T','{}','Edge-core','ECS3510-28T','SWITCH','/upload/icons/edgecore_ecs3510_28t.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(102,'edgecore_es4612','Edge-core ES4612','{}','Edge-core','ES4612','SWITCH','/upload/icons/edgecore_es4612.webp','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(103,'edgecore_es3510ma','Edge-core ES3510MA','{}','Edge-core','ES3510MA','SWITCH','/upload/icons/edgecore_es3510ma.jpeg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(104,'huawei_s2326tp_ei','Huawei S2326TP-EI','{}','Huawei','S2326TP-EI','SWITCH','/upload/icons/S2326TP-EI.jpg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(105,'huawei_s2320_28tp_ei','Huawei S2320-28TP-EI','{}','Huawei','S2320-28TP-EI','SWITCH','/upload/icons/huawei_s2320_28tp_ei.jpeg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(106,'alcatel_general_switch','Alcatel Switch','{}','Alcatel-Lucent','General switches','SWITCH','/upload/icons/alcatel.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(107,'cisco_general_switch','Cisco Switch (NX-OS)','{}','Cisco','General switches','SWITCH','/upload/icons/cisco.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(108,'dell_general_switch','Dell Powerconnect Switch','{}','Dell','General switches','SWITCH','/upload/icons/dell.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(109,'dlink_general_switch','D-link Switch','{}','D-Link','General switches','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(110,'dlink_des_3528','D-link DES-3528','{}','D-Link','DES-3528','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(111,'dlink_des_3026','D-link DES-3026','{}','D-Link','DES-3026','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(112,'dlink_dgs_3612g','D-link DGS-3612G','{}','D-Link','DGS-3612G','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(113,'dlink_dgs_3000_10tc','D-link DGS-3000-10TC','{}','D-Link','DGS-3000-10TC','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(114,'dlink_dgs_1210_12ts_me_b1','D-link DGS-1210-12TS/ME/B1','{}','D-Link','DGS-1210-12TS/ME/B1','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(115,'dlink_dgs_1510_20l_me','D-link DGS-1510-20L/ME','{}','D-Link','DGS-1510-20L/ME','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(116,'hp_general_switch','HP Switch','{}','HP','General switch','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(117,'hp_j9626a_48','HP J9626A 2620-48 Switch','{}','HP','J9626A 2620-48 Switch','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(118,'hp_procurve_j9021a_24','HP ProCurve J9021A Switch 2810-24G','{}','HP','ProCurve J9021A Switch 2810-24G','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(119,'hp_procurve_j9085a_24','HP ProCurve J9085A Switch 2610-24','{}','HP','ProCurve J9085A Switch 2610-24','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(120,'hp_procurve_j9090a_48','HP ProCurve J9020A Switch 2510-48','{}','HP','ProCurve J9020A Switch 2510-48','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(121,'huawei_general_switch','Huawei Switch','{}','Huawei','General switch','SWITCH','/upload/icons/huawei.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(122,'eltex_general_switch','Eltex Switch','{}','Eltex','General switch','SWITCH','/upload/icons/eltex.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(123,'cisco_general_switch_sg','Cisco switch','{}','Cisco','general switch','SWITCH','/upload/icons/cisco.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(124,'ubnt_edge_switch','UBNT EdgeSwitch','{}','UBNT','EdgeSwitch','SWITCH','/upload/icons/ubnt-logo.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(125,'tplink_jetstream_switch','TP-Link JetStream Switch','{}','TP-Link','JetStream','SWITCH','/upload/icons/TP-LINK.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(126,'tplink_smart_switch','TP-Link Smart Switch','{}','TP-Link','Smart switch','SWITCH','/upload/icons/TP-LINK.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(127,'hp_arubaos_switch','HP Switch (ArubaOS)','{}','HP','ArubaOS switch','SWITCH','/upload/icons/arubaos.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(128,'tplink_general_switch','TP-Link switch','{}','TP-Link','general switch','SWITCH','/upload/icons/TP-LINK.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(129,'edgecore_general_switch','Edge-core switch','{}','Edge-core','general switch','SWITCH','/upload/icons/edgecore-networks.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(130,'huawei_s2350_28tp','Huawei S2350-28TP','{}','Huawei','S2350-28TP','SWITCH','/upload/icons/huawei.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(131,'mikrotik_crs','Mikrotik CRS','{}','Mikrotik','CRS','SWITCH','/upload/icons/mikrotik.svg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(132,'raisecom_iscom','Raisecom ISCOM','{}','Raisecom','ISCOM','SWITCH','/upload/icons/raisecom.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(133,'huawei_quidway_S9300_series','Huawei S9300 series','{}','Huawei','S9300 series','SWITCH','/upload/icons/huawei.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(134,'juniper_qfx51xx_series','Juniper QFX5100 series','{}','Juniper','QFX5100 series','SWITCH','/upload/icons/juniper.webp','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 550, \"interfaces_status\": 120}'),(135,'ati_switch_8000','ATI AT-8000 switch','{}','ATI','AT-8000 switch','SWITCH','/upload/icons/at.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 1800, \"sys_resources\": 120, \"interfaces_list\": 550, \"interfaces_status\": 120}'),(136,'hp_procurve_j9079','HP PROCURVE J9079A','{}','HP','J9079A','SWITCH','/upload/icons/hp.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 550, \"interfaces_status\": 120}'),(137,'applynet_sw812','ApplyNet AN-SW812','{}','ApplyNet','AN-SW812','SWITCH','/upload/icons/applynet.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 550, \"interfaces_status\": 120}'),(138,'dlink_dgs_3120_24sc_bx','D-Link DGS-3120-24SC/Bx','{}','D-Link','DGS-3120-24SC/Bx','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(139,'dlink_des_3200_52_c1','D-Link DES-3200-52/C1','{}','D-Link','DES-3200-52/C1','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(140,'hpe_switch','HPE switch','{}','HPE','default switch','SWITCH','/upload/icons/arubaos.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(141,'hp_j9850a','HP J9850A Switch','{}','HPE','J9850A Switch','SWITCH','/upload/icons/arubaos.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(142,'hpe_anw_jl675a','HPE ANW JL675A 6100','{}','HPE','ANW JL675A 6100','SWITCH','/upload/icons/arubaos.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(143,'raisecom_iscom_2600','Raisecom ISCOM 2600','{}','Raisecom','ISCOM 2600','SWITCH','/upload/icons/raisecom.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(144,'arista_default','Arista','{}','Arista','Default','ROUTER','/upload/icons/arista.png','\\WCC\\Routers\\Controllers\\RouterController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(145,'dcn_default','DCN','{}','DCN','Default','SWITCH','/upload/icons/dcn.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(146,'raisecom_default','Raisecom default','{}','Raisecom','Default','SWITCH','/upload/icons/raisecom.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(147,'raisecom_rax721','Raisecom RAX721','{}','Raisecom','RAX721','SWITCH','/upload/icons/raisecom.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(148,'c_data_fd5008_fd5016','CData FD5008-FD5016','{}','CData','FD5008-FD5016','ONU','/upload/icons/cdata.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(149,'swos_default','SwOS Default','{}','Mikrotik','SwOS','SWITCH','/upload/icons/mikrotik.svg','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(150,'dlink_dgs_1210_28x_me_b1','D-link DGS-1210-28X/ME/B1','{}','D-link','DGS-1210-28X/ME/B1','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(151,'dlink_dgs_1210_28_me_b2','D-link DGS-1210-28/ME/B2','{}','D-link','DGS-1210-28/ME/B2','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 300}'),(152,'dlink_dgs_3000_20l','D-link DGS-3000-20L','{}','D-link','DGS-3000-20L','SWITCH','/upload/icons/dlink.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120}'),(153,'eltex_mes14xx_mes24xx_mes3708p','Eltex MES14xx|MES24xx|MES3708P','{}','Eltex','MES14xx|MES24xx|MES3708P','SWITCH','/upload/icons/eltex.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(154,'eltex_mes14xx','Eltex MES14xx','{}','Eltex','MES14xx','SWITCH','/upload/icons/eltex.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(155,'eltex_mes24xx','Eltex MES24xx','{}','Eltex','MES24xx','SWITCH','/upload/icons/eltex.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(156,'eltex_mes3708','Eltex MES3708','{}','Eltex','MES3708','SWITCH','/upload/icons/eltex.png','\\WCC\\Switches\\Controllers\\SwitchesController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(157,'equicom_ping3','Ping3','{}','Equicom','Ping3','SENSOR','/upload/icons/equicom.gif','\\WCC\\SensorDevices\\Controllers\\Controller','{\"system\": 300, \"sensors_data\": 300}'),(158,'juniper_jnp204_series','Juniper JNP204 series','{}','Juniper','JNP204 series','ROUTER','/upload/icons/juniper.webp','\\WCC\\Routers\\Controllers\\RouterController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(159,'extreme_xos','Extreme XOS','{}','Extreme','XOS','ROUTER','/upload/icons/extreme.png','\\WCC\\Routers\\Controllers\\RouterController','{\"system\": 300, \"counters\": 120, \"sys_resources\": 120, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(161,'dell_networking_os','Dell Networking OS','{}','Dell','Networking OS','ROUTER','/upload/icons/dell.png','\\WCC\\Routers\\Controllers\\RouterController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(162,'dell_emc_networking_os','Dell EMC Networking OS','{}','Dell','EMC Networking OS','ROUTER','/upload/icons/dell.png','\\WCC\\Routers\\Controllers\\RouterController','{\"system\": 300, \"counters\": 120, \"fdb_table\": 600, \"sys_resources\": 300, \"interfaces_list\": 1800, \"interfaces_status\": 120, \"sfp_optical_strength\": 600}'),(163,'c_data_fd1700s_fw3','C-Data FD1700 series (FW3)','{\"show_optical_info_from_history\": true}','C-Data','FD1700 series (FW3)','OLT','/upload/icons/cdata.png','\\WCC\\Olts\\Controllers\\Controller','{\"system\": 300, \"counters\": 180, \"fdb_table\": 1800, \"ont_ident\": 600, \"sys_resources\": 180, \"interfaces_list\": 300, \"ont_vendor_info\": 600, \"optical_strength\": 600, \"pon_port_loading\": 300, \"interfaces_status\": 180}');
/*!40000 ALTER TABLE `device_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `access_id` int DEFAULT NULL,
  `model_id` int DEFAULT NULL,
  `params` json DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mac` varchar(50) DEFAULT '',
  `serial` varchar(50) DEFAULT '',
  `enabled` tinyint NOT NULL DEFAULT '1',
  `location` varchar(255) DEFAULT '',
  `group_id` int NOT NULL DEFAULT '-1',
  `pollers` json DEFAULT NULL,
  `coordinates` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_ip_uindex` (`ip`),
  KEY `devices_device_models_id_fk` (`model_id`),
  KEY `devices_device_accesses_id_fk` (`access_id`),
  KEY `devices_device_groups_id_fk` (`group_id`),
  CONSTRAINT `devices_device_accesses_id_fk` FOREIGN KEY (`access_id`) REFERENCES `device_accesses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devices_device_groups_id_fk` FOREIGN KEY (`group_id`) REFERENCES `device_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `devices_device_models_id_fk` FOREIGN KEY (`model_id`) REFERENCES `device_models` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_arp_history`
--

DROP TABLE IF EXISTS `poll_arp_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_arp_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_at` datetime NOT NULL,
  `stop_at` datetime DEFAULT NULL,
  `device_id` int NOT NULL,
  `ip` varchar(100) NOT NULL,
  `mac` varchar(100) NOT NULL,
  `interface` varchar(100) NOT NULL,
  `dynamic` enum('UNKNOWN','YES','NO') DEFAULT 'UNKNOWN',
  `vlan_id` int DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `collector_arps_devices_id_fk` (`device_id`),
  CONSTRAINT `collector_arps_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_arp_history`
--

LOCK TABLES `poll_arp_history` WRITE;
/*!40000 ALTER TABLE `poll_arp_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_arp_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_bgp_sessions`
--

DROP TABLE IF EXISTS `poll_bgp_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_bgp_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `device_id` int NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `instance` varchar(100) DEFAULT NULL,
  `started_at` int DEFAULT NULL,
  `remote_address` varchar(100) DEFAULT NULL,
  `local_address` varchar(100) DEFAULT NULL,
  `remote_id` varchar(100) DEFAULT NULL,
  `remote_as` int DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `disabled` tinyint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `collector_bgp_sessions_devices_id_fk` (`device_id`),
  CONSTRAINT `collector_bgp_sessions_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_bgp_sessions`
--

LOCK TABLES `poll_bgp_sessions` WRITE;
/*!40000 ALTER TABLE `poll_bgp_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_bgp_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_fdb_history`
--

DROP TABLE IF EXISTS `poll_fdb_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_fdb_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_id` int NOT NULL,
  `interface_id` int NOT NULL,
  `mac_address` varchar(17) NOT NULL,
  `vlan_id` int NOT NULL DEFAULT '1',
  `start_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stop_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `poll_fdb_history_interface_id_vlan_id_mac_address_uindex` (`interface_id`,`vlan_id`,`mac_address`),
  KEY `collector_fdb_history_devices_id_fk` (`device_id`),
  KEY `collector_fdb_history_mac_address_index` (`mac_address`),
  CONSTRAINT `collector_fdb_history_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `collector_fdb_history_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_fdb_history`
--

LOCK TABLES `poll_fdb_history` WRITE;
/*!40000 ALTER TABLE `poll_fdb_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_fdb_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_ont_ident`
--

DROP TABLE IF EXISTS `poll_ont_ident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poll_ont_ident` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `interface_id` int NOT NULL,
  `type` enum('MAC','SERIAL') NOT NULL,
  `ident` varchar(50) DEFAULT '',
  `vendor_info` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `collector_ont_ident_interface_id_device_id_uindex` (`interface_id`),
  KEY `collector_ont_ident_ident_index` (`ident`),
  CONSTRAINT `collector_ont_ident_device_interfaces_id_fk` FOREIGN KEY (`interface_id`) REFERENCES `device_interfaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_ont_ident`
--

LOCK TABLES `poll_ont_ident` WRITE;
/*!40000 ALTER TABLE `poll_ont_ident` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_ont_ident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poller_processing`
--

DROP TABLE IF EXISTS `poller_processing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poller_processing` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_at` datetime NOT NULL,
  `stop_at` datetime DEFAULT NULL,
  `device_id` int DEFAULT NULL,
  `status` enum('SUCCESS','FAILED') DEFAULT NULL,
  `error` json DEFAULT NULL,
  `poller` enum('sfp_optical_strength','pon_port_loading','sys_resources','counters','system','interfaces_list','fdb_table','interfaces_status','optical_strength','ont_ident','bgp_sessions','arp_table','sensors_data','ont_vendor_info','cards_status') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `collector_processing_devices_id_fk` (`device_id`),
  KEY `collector_processing_start_at_index` (`start_at`),
  KEY `collector_processing_collector_index` (`poller`),
  CONSTRAINT `collector_processing_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poller_processing`
--

LOCK TABLES `poller_processing` WRITE;
/*!40000 ALTER TABLE `poller_processing` DISABLE KEYS */;
/*!40000 ALTER TABLE `poller_processing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switcher_core_actions`
--

DROP TABLE IF EXISTS `switcher_core_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `switcher_core_actions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `user_id` int NOT NULL,
  `device_id` int NOT NULL,
  `status` enum('SUCCESS','FAILED') NOT NULL DEFAULT 'SUCCESS',
  `hash` varchar(50) NOT NULL,
  `module` varchar(100) NOT NULL,
  `arguments` json DEFAULT NULL,
  `data` json DEFAULT NULL,
  `meta` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `switcher_core_actions_devices_id_fk` (`device_id`),
  KEY `switcher_core_actions_users_id_fk` (`user_id`),
  KEY `switcher_core_actions_time_index` (`time` DESC),
  CONSTRAINT `switcher_core_actions_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `switcher_core_actions_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switcher_core_actions`
--

LOCK TABLES `switcher_core_actions` WRITE;
/*!40000 ALTER TABLE `switcher_core_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `switcher_core_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_actions`
--

DROP TABLE IF EXISTS `system_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_actions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `action` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `meta` json DEFAULT NULL,
  `status` enum('SUCCESS','FAILED') DEFAULT 'SUCCESS',
  `device_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_actions_users_id_fk` (`user_id`),
  KEY `system_actions_action_index` (`action`),
  KEY `system_actions_created_at_index` (`created_at`),
  KEY `system_actions_devices_id_fk` (`device_id`),
  CONSTRAINT `system_actions_devices_id_fk` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `system_actions_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_actions`
--

LOCK TABLES `system_actions` WRITE;
/*!40000 ALTER TABLE `system_actions` DISABLE KEYS */;
INSERT INTO `system_actions` VALUES (1,'2026-08-18 08:46:13','user:logged_out',1,'User logged out from system',NULL,'SUCCESS',NULL),(2,'2026-08-18 08:46:18','user:logged_in',1,'User success logined from IP 192.168.137.1','{\"dev_info\": {\"bot\": null, \"brand\": \"\", \"model\": \"\", \"client\": {\"name\": \"Chrome\", \"type\": \"browser\", \"engine\": \"Blink\", \"family\": \"Chrome\", \"version\": \"151.0.0.0\", \"short_name\": \"CH\", \"engine_version\": \"151.0.0.0\"}, \"device\": \"desktop\", \"os_info\": {\"name\": \"Windows\", \"family\": \"Windows\", \"version\": 10, \"platform\": \"x64\", \"short_name\": \"WIN\"}}, \"remote_addr\": \"192.168.137.1\", \"key_expired_at\": \"2026-08-28 08:46:18\"}','SUCCESS',NULL);
/*!40000 ALTER TABLE `system_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_components`
--

DROP TABLE IF EXISTS `system_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_components` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `key` varchar(50) NOT NULL,
  `namespace` varchar(50) DEFAULT NULL,
  `enabled` tinyint NOT NULL DEFAULT '0',
  `built_in` tinyint NOT NULL DEFAULT '0',
  `configuration` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_components_key_uindex` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_components`
--

LOCK TABLES `system_components` WRITE;
/*!40000 ALTER TABLE `system_components` DISABLE KEYS */;
INSERT INTO `system_components` VALUES (3,'Events integration','events',NULL,1,0,NULL),(4,'MikBill integration','mikbill_integration',NULL,0,0,'[]'),(5,'Prometheus wrapper','prometheus_wrapper',NULL,1,0,'[]'),(6,'OLTs','olts',NULL,1,0,NULL),(7,'LiveTraffic graph builder','live_traffic',NULL,1,0,'[]'),(8,'ICMP pinger integration','pinger',NULL,1,0,NULL),(9,'FDB history from collector','fdb_history',NULL,1,0,NULL),(10,'Autodiscovery devices','autodiscovery',NULL,1,0,'[]'),(11,'Diagnostic API','diagnostic',NULL,1,0,'[]'),(12,'Working with RouterOS system','router_os',NULL,1,0,NULL),(13,'SearchDevice system','search_device',NULL,1,0,'[]'),(14,'Userside API integration','userside_integration',NULL,0,0,'[]'),(15,'QrGenerator','qr-generator',NULL,1,0,'[]'),(16,'Oxidized config backup system','oxidized',NULL,1,0,'[]'),(17,'Switches','switches',NULL,1,0,NULL),(18,'NoDeny API','nodeny_plus',NULL,0,0,'[]'),(19,'PonBoxes API','pon_boxes',NULL,1,0,'{\"icons\": {\"OLT\": \"<svg width=\\\"48\\\" height=\\\"48\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><g><title>Layer 1</title><ellipse stroke=\\\"#2571bc\\\" ry=\\\"19.98474\\\" rx=\\\"19.98474\\\" id=\\\"svg_6\\\" cy=\\\"23.7607\\\" cx=\\\"23.97368\\\" fill=\\\"#586dc4\\\"/><rect transform=\\\"rotate(45 23.9355 23.8751)\\\" stroke=\\\"#e2a871\\\" id=\\\"svg_3\\\" height=\\\"32.418\\\" width=\\\"32.418\\\" y=\\\"7.66612\\\" x=\\\"7.72655\\\" fill=\\\"#ffd4aa\\\"/></g></svg>\", \"ONU\": \"<svg width=\\\"32\\\" height=\\\"32\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"> <g id=\\\"Layer_1\\\">  <title>Layer 1</title>  <path stroke=\\\"#ffffff\\\" id=\\\"svg_1\\\" d=\\\"m0.08699,15.97296l0,0c0,-8.77886 7.11667,-15.89553 15.89552,-15.89553l0,0c4.21575,0 8.25884,1.6747 11.23983,4.65569c2.98099,2.98099 4.65569,7.02408 4.65569,11.23984l0,0c0,8.77886 -7.11667,15.89553 -15.89552,15.89553l0,0c-8.77885,0 -15.89552,-7.11667 -15.89552,-15.89553zm7.94776,0l0,0c0,4.38943 3.55834,7.94776 7.94776,7.94776c4.38943,0 7.94776,-3.55834 7.94776,-7.94776c0,-4.38943 -3.55834,-7.94776 -7.94776,-7.94776l0,0c-4.38942,0 -7.94776,3.55834 -7.94776,7.94776z\\\" fill=\\\"#3a3eb7\\\"/>  <path stroke=\\\"#ffffff\\\" id=\\\"svg_4\\\" d=\\\"m8.40117,15.86036l1.43237,-4.50318l3.74998,-2.78315l4.6353,0l3.75,2.78315l1.43235,4.50318l-1.43235,4.50318l-3.75,2.78315l-4.6353,0l-3.74998,-2.78315l-1.43237,-4.50318z\\\" fill=\\\"#babcf4\\\"/> </g></svg>\", \"ROUTER\": \"<svg width=\\\"48\\\" height=\\\"48\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><g><title>Layer 1</title><ellipse stroke=\\\"#2571bc\\\" ry=\\\"19.98474\\\" rx=\\\"19.98474\\\" id=\\\"svg_6\\\" cy=\\\"23.7607\\\" cx=\\\"23.97368\\\" fill=\\\"#586dc4\\\"/><rect transform=\\\"rotate(45 23.9355 23.8751)\\\" stroke=\\\"#e2a871\\\" id=\\\"svg_3\\\" height=\\\"32.418\\\" width=\\\"32.418\\\" y=\\\"7.66612\\\" x=\\\"7.72655\\\" fill=\\\"#ffd4aa\\\"/></g></svg>\", \"SWITCH\": \"<svg width=\\\"48\\\" height=\\\"48\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><g><title>Layer 1</title><ellipse stroke=\\\"#2571bc\\\" ry=\\\"19.98474\\\" rx=\\\"19.98474\\\" id=\\\"svg_6\\\" cy=\\\"23.7607\\\" cx=\\\"23.97368\\\" fill=\\\"#586dc4\\\"/><rect transform=\\\"rotate(45 23.9355 23.8751)\\\" stroke=\\\"#e2a871\\\" id=\\\"svg_3\\\" height=\\\"32.418\\\" width=\\\"32.418\\\" y=\\\"7.66612\\\" x=\\\"7.72655\\\" fill=\\\"#ffd4aa\\\"/></g></svg>\"}}'),(20,'OLTs control','olts_control',NULL,1,0,NULL),(21,'Sensor devices','sensor_devices',NULL,1,0,NULL),(22,'Switches control','switches_control',NULL,1,0,NULL),(23,'Links dependencies','links',NULL,1,0,NULL),(24,'Notifications','notifications',NULL,1,0,NULL),(25,'Allow execute some commands','macros',NULL,1,0,NULL),(26,'Allow to registration ONT','onts_registration',NULL,1,0,NULL),(27,'Auto links (network tree)','auto_topology',NULL,1,0,NULL),(28,'Attachments','attachments',NULL,1,0,'[]'),(29,'Working with device console','console',NULL,1,0,'[]'),(30,'Analytics API','analytics',NULL,1,0,'[]'),(31,'Working with routers (L3 devices)','routers',NULL,1,0,NULL),(32,'SNMP trap service','trapservice',NULL,1,0,'[]'),(33,'Transport paths','paths',NULL,1,0,NULL);
/*!40000 ALTER TABLE `system_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_schedule`
--

DROP TABLE IF EXISTS `system_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `latest` datetime DEFAULT NULL,
  `component_id` int DEFAULT NULL,
  `crontab` varchar(50) NOT NULL,
  `command` varchar(255) NOT NULL,
  `state` enum('ENABLED','DISABLED') NOT NULL DEFAULT 'ENABLED',
  `editable` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `system_schedule_command_period_uindex` (`command`,`crontab`),
  UNIQUE KEY `system_schedule_key_uindex` (`key`),
  KEY `system_schedule_system_components_component_id_fk` (`component_id`),
  CONSTRAINT `system_schedule_system_components_component_id_fk` FOREIGN KEY (`component_id`) REFERENCES `system_components` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_schedule`
--

LOCK TABLES `system_schedule` WRITE;
/*!40000 ALTER TABLE `system_schedule` DISABLE KEYS */;
INSERT INTO `system_schedule` VALUES (2,'clear_switcher_core_logs','2026-04-14 14:48:40','2026-08-07 12:30:02',NULL,'30 */6 * * *','wca logs:clear switcher-core 1','ENABLED',1),(3,'clear_action_logs','2026-04-14 14:48:40',NULL,NULL,'0 0 * * *','wca logs:clear actions 30','ENABLED',1),(4,'clear_collector_logs','2026-04-14 14:48:40','2026-07-25 12:00:01',NULL,'0 */6 * * *','wca logs:clear collector 1','ENABLED',1),(5,'clear_crontab_report_logs','2026-04-14 14:48:40','2026-08-17 18:20:02',NULL,'20 */6 * * *','wca logs:clear crontab-reports 2','ENABLED',1),(6,'prometheus_meta_exporter','2026-04-14 14:48:40','2026-08-21 09:38:01',NULL,'*/2 * * * *','wca system:prom-metrics-exporter','ENABLED',1),(7,'recalc_user_sessions','2022-04-22 22:34:16','2026-08-21 09:38:01',NULL,'*/2 * * * *','wca system:recalc-sessions','ENABLED',0),(8,'sys_logrotate','2026-04-14 14:48:40',NULL,NULL,'0 0 * * *','logrotate /etc/logrotate.d/support.conf','ENABLED',0),(9,'clear_expired_sessions','2026-04-14 14:48:40',NULL,NULL,'1 0 * * *','wca logs:clear expired-sessions 30','ENABLED',1),(10,'events_apply_rules_reboot','2026-04-14 14:48:46','2026-08-21 09:35:19',3,'@reboot','sleep 60 && wca events:apply-rules','ENABLED',0),(11,'events_apply_rules_cycle','2026-04-14 14:48:46','2026-08-21 09:38:01',3,'* 9 * * *','sleep 60 && wca events:apply-rules','ENABLED',1),(12,'events_retention','2026-04-14 14:48:46',NULL,3,'10 0 * * * ','wca events:retention 30','ENABLED',1),(13,'mikbill_sync_clients','2026-04-14 14:48:47',NULL,4,'10 6-22 * * *','wca mikbill_integration:sync-clients','ENABLED',1),(14,'pinger_recalc_exporter_statuses','2026-04-14 14:48:50','2026-08-21 09:38:01',8,'*/2 * * * *','wca pinger:update-exporter-statuses','ENABLED',1),(15,'autodiscovery_search_devices','2026-04-14 14:48:52','2026-08-18 09:00:01',10,'*/30 6-23 * * *','wca autodiscovery:scan','ENABLED',1),(16,'userside_integration_sync','2026-04-14 14:48:55','2026-08-17 19:10:02',14,'10 6-22 * * *','wca userside_integration:sync','ENABLED',1),(17,'nodeny_plus_sync_clients','2026-04-14 14:48:58',NULL,18,'*/10 6-23 * * *','wca nodeny_plus:sync-clients','DISABLED',1),(18,'links_prom_exporter','2026-04-14 14:49:02','2026-08-21 09:38:01',23,'*/2 * * * *','wca links:calc-link-utilization','ENABLED',1),(19,'clear_old_notifications','2026-04-14 14:49:03',NULL,24,'1 0 * * *','wca logs:clear notifications 30','ENABLED',1),(20,'check_unregistered_onts','2026-04-14 14:49:05','2026-08-18 09:00:01',26,'*/5 8-22 * * *','wca onts_registration:get-unregistered-onts','ENABLED',1),(21,'auto_topology_scan','2026-04-14 14:49:06','2026-08-18 09:00:01',27,'0 */3 * * *','wca auto_topology:scan --schedule','ENABLED',1),(22,'auto_topology_clearing','2026-04-14 14:49:06',NULL,27,'0 0 * * *','wca auto_topology:clear-not-actual-links','ENABLED',1),(23,'analytics_prom_exporter','2026-04-14 14:49:09','2026-08-21 09:38:01',30,'*/2 * * * *','wca analytics:duplicated-mac-addresses && wca analytics:duplicated-ont-idents','ENABLED',1),(24,'trapservice_clear_old_logs','2026-04-14 14:49:11','2026-07-25 12:00:02',32,'0 */3 * * *','wca trapservice:clear-old-logs 30','DISABLED',1),(25,'openapi_doc','2026-08-17 16:54:10','2026-08-21 09:35:19',NULL,'@reboot','wca openapi:generate','ENABLED',0),(26,'events_sync_active_alerts','2026-08-17 16:54:28','2026-08-18 09:00:01',3,'*/10 * * * *','sleep 300 && wca events:sync-active-alerts','ENABLED',1),(27,'paths_state_calculator','2026-08-17 19:03:18','2026-08-21 09:38:01',33,'*/1 * * * *','wca paths:calc-state','ENABLED',1);
/*!40000 ALTER TABLE `system_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_schedule_reports`
--

DROP TABLE IF EXISTS `system_schedule_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_schedule_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `start_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stop_at` datetime DEFAULT NULL,
  `output` longtext,
  `error` text,
  `is_successful` tinyint DEFAULT NULL,
  `schedule_id` int NOT NULL,
  UNIQUE KEY `system_schedule_reports_pk` (`id`),
  KEY `system_schedule_reports_system_crontab_id_fk` (`schedule_id`),
  KEY `system_schedule_reports_start_at_index` (`start_at`),
  CONSTRAINT `system_schedule_reports_system_crontab_id_fk` FOREIGN KEY (`schedule_id`) REFERENCES `system_schedule` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_schedule_reports`
--

LOCK TABLES `system_schedule_reports` WRITE;
/*!40000 ALTER TABLE `system_schedule_reports` DISABLE KEYS */;
INSERT INTO `system_schedule_reports` VALUES (1,'2026-08-18 08:20:01','2026-08-18 08:20:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(2,'2026-08-18 08:20:01','2026-08-18 08:20:02','Recalculated. Count affected keys = 0\n','',1,7),(3,'2026-08-18 08:20:01','2026-08-18 08:20:02','Start update metrics...\nSuccess updated!\n','',1,14),(4,'2026-08-18 08:20:01','2026-08-18 08:20:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(5,'2026-08-18 08:20:01','2026-08-18 08:20:02','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(6,'2026-08-18 08:20:01','2026-08-18 08:20:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(7,'2026-08-18 08:20:01','2026-08-18 08:25:02','Fetched 0 active alerts from alertmanager\nLoaded 0 unresolved events from storage\nDone. resolved=0, skipped=0\n','',1,26),(8,'2026-08-18 08:20:01','2026-08-18 08:20:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(9,'2026-08-18 08:25:02','2026-08-18 08:25:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(10,'2026-08-18 08:25:02','2026-08-18 08:25:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(11,'2026-08-18 08:26:01','2026-08-18 08:26:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(12,'2026-08-18 08:26:01','2026-08-18 08:26:02','Recalculated. Count affected keys = 0\n','',1,7),(13,'2026-08-18 08:26:01','2026-08-18 08:26:02','Start update metrics...\nSuccess updated!\n','',1,14),(14,'2026-08-18 08:26:01','2026-08-18 08:26:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(15,'2026-08-18 08:26:01','2026-08-18 08:26:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(16,'2026-08-18 08:26:01','2026-08-18 08:26:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(17,'2026-08-18 08:27:01','2026-08-18 08:27:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(18,'2026-08-18 08:28:02','2026-08-18 08:28:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(19,'2026-08-18 08:28:02','2026-08-18 08:28:03','Recalculated. Count affected keys = 0\n','',1,7),(20,'2026-08-18 08:28:02','2026-08-18 08:28:03','Start update metrics...\nSuccess updated!\n','',1,14),(21,'2026-08-18 08:28:02','2026-08-18 08:28:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(22,'2026-08-18 08:28:02','2026-08-18 08:28:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(23,'2026-08-18 08:28:02','2026-08-18 08:28:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(24,'2026-08-18 08:29:02','2026-08-18 08:29:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(25,'2026-08-18 08:31:02','2026-08-18 08:31:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(26,'2026-08-18 08:32:02','2026-08-18 08:32:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(27,'2026-08-18 08:32:02','2026-08-18 08:32:03','Recalculated. Count affected keys = 0\n','',1,7),(28,'2026-08-18 08:32:02','2026-08-18 08:32:03','Start update metrics...\nSuccess updated!\n','',1,14),(29,'2026-08-18 08:32:02','2026-08-18 08:32:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(30,'2026-08-18 08:32:02','2026-08-18 08:32:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(31,'2026-08-18 08:32:02','2026-08-18 08:32:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(32,'2026-08-18 08:33:01','2026-08-18 08:33:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(33,'2026-08-18 08:34:01','2026-08-18 08:34:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(34,'2026-08-18 08:34:01','2026-08-18 08:34:03','Recalculated. Count affected keys = 0\n','',1,7),(35,'2026-08-18 08:34:01','2026-08-18 08:34:03','Start update metrics...\nSuccess updated!\n','',1,14),(36,'2026-08-18 08:34:01','2026-08-18 08:34:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(37,'2026-08-18 08:34:01','2026-08-18 08:34:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(38,'2026-08-18 08:34:01','2026-08-18 08:34:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(39,'2026-08-18 08:35:02','2026-08-18 08:35:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(40,'2026-08-18 08:35:02','2026-08-18 08:35:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(41,'2026-08-18 08:30:02','2026-08-18 08:30:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(42,'2026-08-18 08:30:02','2026-08-18 08:30:03','Recalculated. Count affected keys = 0\n','',1,7),(43,'2026-08-18 08:30:02','2026-08-18 08:30:03','Start update metrics...\nSuccess updated!\n','',1,14),(44,'2026-08-18 08:30:02','2026-08-18 08:30:03','Scan finished\nFinished!\n','',1,15),(45,'2026-08-18 08:30:02','2026-08-18 08:30:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(46,'2026-08-18 08:30:02','2026-08-18 08:30:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(47,'2026-08-18 08:30:02','2026-08-18 08:30:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(48,'2026-08-18 08:30:02','2026-08-18 08:35:03','Fetched 0 active alerts from alertmanager\nLoaded 0 unresolved events from storage\nDone. resolved=0, skipped=0\n','',1,26),(49,'2026-08-18 08:30:02','2026-08-18 08:30:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(50,'2026-08-18 08:36:01','2026-08-18 08:36:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(51,'2026-08-18 08:36:01','2026-08-18 08:36:02','Recalculated. Count affected keys = 0\n','',1,7),(52,'2026-08-18 08:36:01','2026-08-18 08:36:02','Start update metrics...\nSuccess updated!\n','',1,14),(53,'2026-08-18 08:36:01','2026-08-18 08:36:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(54,'2026-08-18 08:36:01','2026-08-18 08:36:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(55,'2026-08-18 08:36:01','2026-08-18 08:36:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(56,'2026-08-18 08:37:01','2026-08-18 08:37:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(57,'2026-08-18 08:38:02','2026-08-18 08:38:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(58,'2026-08-18 08:38:02','2026-08-18 08:38:03','Recalculated. Count affected keys = 0\n','',1,7),(59,'2026-08-18 08:38:02','2026-08-18 08:38:03','Start update metrics...\nSuccess updated!\n','',1,14),(60,'2026-08-18 08:38:02','2026-08-18 08:38:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(61,'2026-08-18 08:38:02','2026-08-18 08:38:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(62,'2026-08-18 08:38:02','2026-08-18 08:38:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(63,'2026-08-18 08:39:02','2026-08-18 08:39:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(64,'2026-08-18 08:41:02','2026-08-18 08:41:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(65,'2026-08-18 08:42:02','2026-08-18 08:42:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(66,'2026-08-18 08:42:02','2026-08-18 08:42:03','Recalculated. Count affected keys = 0\n','',1,7),(67,'2026-08-18 08:42:02','2026-08-18 08:42:03','Start update metrics...\nSuccess updated!\n','',1,14),(68,'2026-08-18 08:42:02','2026-08-18 08:42:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(69,'2026-08-18 08:42:02','2026-08-18 08:42:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(70,'2026-08-18 08:42:02','2026-08-18 08:42:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(71,'2026-08-18 08:43:01','2026-08-18 08:43:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(72,'2026-08-18 08:44:02','2026-08-18 08:44:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(73,'2026-08-18 08:44:02','2026-08-18 08:44:03','Recalculated. Count affected keys = 0\n','',1,7),(74,'2026-08-18 08:44:02','2026-08-18 08:44:03','Start update metrics...\nSuccess updated!\n','',1,14),(75,'2026-08-18 08:44:02','2026-08-18 08:44:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(76,'2026-08-18 08:44:02','2026-08-18 08:44:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(77,'2026-08-18 08:44:02','2026-08-18 08:44:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(78,'2026-08-18 08:45:02','2026-08-18 08:45:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(79,'2026-08-18 08:45:02','2026-08-18 08:45:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(80,'2026-08-18 08:40:02','2026-08-18 08:40:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(81,'2026-08-18 08:40:02','2026-08-18 08:40:03','Recalculated. Count affected keys = 0\n','',1,7),(82,'2026-08-18 08:40:02','2026-08-18 08:40:03','Start update metrics...\nSuccess updated!\n','',1,14),(83,'2026-08-18 08:40:02','2026-08-18 08:40:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(84,'2026-08-18 08:40:02','2026-08-18 08:40:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(85,'2026-08-18 08:40:02','2026-08-18 08:40:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(86,'2026-08-18 08:40:02','2026-08-18 08:45:03','Fetched 0 active alerts from alertmanager\nLoaded 0 unresolved events from storage\nDone. resolved=0, skipped=0\n','',1,26),(87,'2026-08-18 08:40:02','2026-08-18 08:40:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(88,'2026-08-18 08:46:01','2026-08-18 08:46:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(89,'2026-08-18 08:46:01','2026-08-18 08:46:02','Recalculated. Count affected keys = 0\n','',1,7),(90,'2026-08-18 08:46:01','2026-08-18 08:46:02','Start update metrics...\nSuccess updated!\n','',1,14),(91,'2026-08-18 08:46:01','2026-08-18 08:46:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(92,'2026-08-18 08:46:01','2026-08-18 08:46:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(93,'2026-08-18 08:46:01','2026-08-18 08:46:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(94,'2026-08-18 08:47:02','2026-08-18 08:47:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(95,'2026-08-18 08:48:02','2026-08-18 08:48:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(96,'2026-08-18 08:48:02','2026-08-18 08:48:03','Recalculated. Count affected keys = 0\n','',1,7),(97,'2026-08-18 08:48:02','2026-08-18 08:48:03','Start update metrics...\nSuccess updated!\n','',1,14),(98,'2026-08-18 08:48:02','2026-08-18 08:48:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(99,'2026-08-18 08:48:02','2026-08-18 08:48:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(100,'2026-08-18 08:48:02','2026-08-18 08:48:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(101,'2026-08-18 08:49:02','2026-08-18 08:49:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(102,'2026-08-18 08:51:02','2026-08-18 08:51:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(103,'2026-08-18 08:52:01','2026-08-18 08:52:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(104,'2026-08-18 08:52:01','2026-08-18 08:52:02','Recalculated. Count affected keys = 0\n','',1,7),(105,'2026-08-18 08:52:01','2026-08-18 08:52:02','Start update metrics...\nSuccess updated!\n','',1,14),(106,'2026-08-18 08:52:01','2026-08-18 08:52:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(107,'2026-08-18 08:52:01','2026-08-18 08:52:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(108,'2026-08-18 08:52:01','2026-08-18 08:52:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(109,'2026-08-18 08:53:02','2026-08-18 08:53:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(110,'2026-08-18 08:54:02','2026-08-18 08:54:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(111,'2026-08-18 08:54:02','2026-08-18 08:54:03','Recalculated. Count affected keys = 0\n','',1,7),(112,'2026-08-18 08:54:02','2026-08-18 08:54:03','Start update metrics...\nSuccess updated!\n','',1,14),(113,'2026-08-18 08:54:02','2026-08-18 08:54:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(114,'2026-08-18 08:54:02','2026-08-18 08:54:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(115,'2026-08-18 08:54:02','2026-08-18 08:54:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(116,'2026-08-18 08:55:02','2026-08-18 08:55:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(117,'2026-08-18 08:55:02','2026-08-18 08:55:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(118,'2026-08-18 08:50:02','2026-08-18 08:50:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(119,'2026-08-18 08:50:02','2026-08-18 08:50:03','Recalculated. Count affected keys = 0\n','',1,7),(120,'2026-08-18 08:50:02','2026-08-18 08:50:03','Start update metrics...\nSuccess updated!\n','',1,14),(121,'2026-08-18 08:50:02','2026-08-18 08:50:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(122,'2026-08-18 08:50:02','2026-08-18 08:50:03','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(123,'2026-08-18 08:50:02','2026-08-18 08:50:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(124,'2026-08-18 08:50:02','2026-08-18 08:55:03','Fetched 0 active alerts from alertmanager\nLoaded 0 unresolved events from storage\nDone. resolved=0, skipped=0\n','',1,26),(125,'2026-08-18 08:50:02','2026-08-18 08:50:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(126,'2026-08-18 08:56:01','2026-08-18 08:56:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(127,'2026-08-18 08:56:01','2026-08-18 08:56:02','Recalculated. Count affected keys = 0\n','',1,7),(128,'2026-08-18 08:56:01','2026-08-18 08:56:02','Start update metrics...\nSuccess updated!\n','',1,14),(129,'2026-08-18 08:56:01','2026-08-18 08:56:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(130,'2026-08-18 08:56:01','2026-08-18 08:56:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(131,'2026-08-18 08:56:01','2026-08-18 08:56:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(132,'2026-08-18 08:57:02','2026-08-18 08:57:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(133,'2026-08-18 08:58:02','2026-08-18 08:58:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(134,'2026-08-18 08:58:02','2026-08-18 08:58:03','Recalculated. Count affected keys = 0\n','',1,7),(135,'2026-08-18 08:58:02','2026-08-18 08:58:03','Start update metrics...\nSuccess updated!\n','',1,14),(136,'2026-08-18 08:58:02','2026-08-18 08:58:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(137,'2026-08-18 08:58:02','2026-08-18 08:58:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(138,'2026-08-18 08:58:02','2026-08-18 08:58:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(139,'2026-08-18 08:59:02','2026-08-18 08:59:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(140,'2026-08-18 09:01:01','2026-08-18 09:02:02','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(141,'2026-08-18 09:01:01','2026-08-18 09:01:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(142,'2026-08-18 09:02:01','2026-08-18 09:02:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(143,'2026-08-18 09:02:01','2026-08-18 09:02:02','Recalculated. Count affected keys = 0\n','',1,7),(144,'2026-08-18 09:02:01','2026-08-18 09:03:02','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(145,'2026-08-18 09:02:01','2026-08-18 09:02:02','Start update metrics...\nSuccess updated!\n','',1,14),(146,'2026-08-18 09:02:01','2026-08-18 09:02:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(147,'2026-08-18 09:02:01','2026-08-18 09:02:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(148,'2026-08-18 09:02:01','2026-08-18 09:02:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(149,'2026-08-18 09:03:02','2026-08-18 09:04:03','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(150,'2026-08-18 09:03:02','2026-08-18 09:03:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(151,'2026-08-18 09:00:01','2026-08-18 09:00:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(152,'2026-08-18 09:00:01','2026-08-18 09:00:02','Recalculated. Count affected keys = 0\n','',1,7),(153,'2026-08-18 09:00:01','2026-08-18 09:01:02','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(154,'2026-08-18 09:00:01','2026-08-18 09:00:02','Start update metrics...\nSuccess updated!\n','',1,14),(155,'2026-08-18 09:00:01','2026-08-18 09:00:02','Scan finished\nFinished!\n','',1,15),(156,'2026-08-18 09:00:01','2026-08-18 09:00:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(157,'2026-08-18 09:00:01','2026-08-18 09:00:02','Start checking all OLTs\n+----+------+-----------+------+--------+-----+-------+----------+\n| Ip | Name | Interface | Type | Serial | Mac | Model | Reg time |\n+----+------+-----------+------+--------+-----+-------+----------+\n','',1,20),(158,'2026-08-18 09:00:01','2026-08-18 09:00:02','Running auto-topology builder manually\nStart execute command \'/www/components/AutoTopology/bin/auto-topology -c /www/components/AutoTopology/bin/config.yml\'\nLoaded configuration from /www/components/AutoTopology/bin/config.yml with env readed:\ntopology:\n  build_by_fdb: true\n  build_by_lldp: true\n  # После построения всех связей, если остаются порты с более 1 мак-адресом - исключить устройства с ранее установленными аплинками (внесенные вручную или автоматически)\n  split_by_vlans: true #Данный параметр имеет смысл применять, если есть роутеры, на которых маршрутится железо\n  build_all: true # Пытается собрать по всем устройствам\n  exclude_not_responded_devices: false\n\n\nlogger:\n  level: trace\ninput: support\noutput: support\n\ninputs:\n  support:\n    base_url: \"http://wca-nginx\"\noutputs:\n  # Складывается в файлы, в формате CSV.\n  # Device-IP - IP устройтва\n  # Формат - DeviceID;DeviceIP;DevicePortName;DevicePortID;NeighborIP;NeighborPortName;NeighborPortID;NeighborType;DetectMethodType\n  files:\n    path: /tmp/links.csv\n  support:\n    base_url: \"http://wca-nginx\"\n\n# Должен использоваться API switcher core\n# https://github.com/meklis/switcher-core-api\n# или подобное API\nswitcher_core:\n  threads: 10\n  timeout: 300s\n  base_url: \"http://wca-nginx\"\n  methods:\n    # Для форматирования линков используется шаблонизатор text/template\n    network_settings: \"/api/v1/switcher-core/cache/net_settings/{{.ID}}\"\n    lldp_info: \"/api/v1/switcher-core/cache/lldp_info/{{.ID}}\"\n    fdb: \"/api/v1/switcher-core/cache/fdb/{{.ID}}\"\n    arps: \"/api/v1/switcher-core/cache/arps/{{.ID}}\"\n\n\ntime=\"2026-08-18 09:00:01\" level=info msg=\"Configuration success initialized!\"\nERR: panic: Input not correct\n\ngoroutine 1 [running]:\nmain.getInput()\n	/home/meklis/projects/wildcore/agent/auto-topology/main.go:99 +0x108\nmain.main()\n	/home/meklis/projects/wildcore/agent/auto-topology/main.go:53 +0x105\n','\nIn RunAutoTopology.php line 140:\n                                                                               \n  The command \"/www/components/AutoTopology/bin/auto-topology -c /www/compone  \n  nts/AutoTopology/bin/config.yml\" failed.                                     \n                                                                               \n  Exit Code: 2(Misuse of shell builtins)                                       \n                                                                               \n  Working directory: /www                                                      \n                                                                               \n  Output:                                                                      \n  ================                                                             \n  Loaded configuration from /www/components/AutoTopology/bin/config.yml with   \n  env readed:                                                                  \n  topology:                                                                    \n    build_by_fdb: true                                                         \n    build_by_lldp: true                                                        \n    # После построения всех связей, если остаются порты с более 1 мак-адресом  \n   - исключить устройства с ранее установленными аплинками (внесенные вручную  \n   или автоматически)                                                          \n    split_by_vlans: true #Данный параметр имеет смысл применять, если есть ро  \n  утеры, на которых маршрутится железо                                         \n    build_all: true # Пытается собрать по всем устройствам                     \n    exclude_not_responded_devices: false                                       \n                                                                               \n                                                                               \n  logger:                                                                      \n    level: trace                                                               \n  input: support                                                               \n  output: support                                                              \n                                                                               \n  inputs:                                                                      \n    support:                                                                   \n      base_url: \"http://wca-nginx\"                                             \n  outputs:                                                                     \n    # Складывается в файлы, в формате CSV.                                     \n    # Device-IP - IP устройтва                                                 \n    # Формат - DeviceID;DeviceIP;DevicePortName;DevicePortID;NeighborIP;Neigh  \n  borPortName;NeighborPortID;NeighborType;DetectMethodType                     \n    files:                                                                     \n      path: /tmp/links.csv                                                     \n    support:                                                                   \n      base_url: \"http://wca-nginx\"                                             \n                                                                               \n  # Должен использоваться API switcher core                                    \n  # https://github.com/meklis/switcher-core-api                                \n  # или подобное API                                                           \n  switcher_core:                                                               \n    threads: 10                                                                \n    timeout: 300s                                                              \n    base_url: \"http://wca-nginx\"                                               \n    methods:                                                                   \n      # Для форматирования линков используется шаблонизатор text/template      \n      network_settings: \"/api/v1/switcher-core/cache/net_settings/{{.ID}}\"     \n      lldp_info: \"/api/v1/switcher-core/cache/lldp_info/{{.ID}}\"               \n      fdb: \"/api/v1/switcher-core/cache/fdb/{{.ID}}\"                           \n      arps: \"/api/v1/switcher-core/cache/arps/{{.ID}}\"                         \n                                                                               \n                                                                               \n  time=\"2026-08-18 09:00:01\" level=info msg=\"Configuration success initialize  \n  d!\"                                                                          \n                                                                               \n                                                                               \n  Error Output:                                                                \n  ================                                                             \n  panic: Input not correct                                                     \n                                                                               \n  goroutine 1 [running]:                                                       \n  main.getInput()                                                              \n  	/home/meklis/projects/wildcore/agent/auto-topology/main.go:99 +0x108         \n  main.main()                                                                  \n  	/home/meklis/projects/wildcore/agent/auto-topology/main.go:53 +0x105         \n                                                                               \n\nauto_topology:scan [-schedule|--schedule|--no-schedule]\n\n',0,21),(159,'2026-08-18 09:00:01','2026-08-18 09:00:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(160,'2026-08-18 09:00:01','2026-08-18 09:05:02','Fetched 0 active alerts from alertmanager\nLoaded 0 unresolved events from storage\nDone. resolved=0, skipped=0\n','',1,26),(161,'2026-08-18 09:00:01','2026-08-18 09:00:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(162,'2026-08-18 09:04:02','2026-08-18 09:04:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(163,'2026-08-18 09:04:02','2026-08-18 09:04:03','Recalculated. Count affected keys = 0\n','',1,7),(164,'2026-08-18 09:04:02','2026-08-18 09:05:03','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(165,'2026-08-18 09:04:02','2026-08-18 09:04:03','Start update metrics...\nSuccess updated!\n','',1,14),(166,'2026-08-18 09:04:02','2026-08-18 09:04:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(167,'2026-08-18 09:04:02','2026-08-18 09:04:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(168,'2026-08-18 09:04:02','2026-08-18 09:04:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(169,'2026-08-20 10:04:59','2026-08-20 10:06:00','Found 25 rules in storage, try apply\nSuccess!\n','',1,10),(170,'2026-08-20 10:04:59','2026-08-20 10:05:01','','',1,25),(171,'2026-08-20 10:06:02','2026-08-20 10:06:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(172,'2026-08-20 10:06:02','2026-08-20 10:06:03','Recalculated. Count affected keys = 0\n','',1,7),(173,'2026-08-20 10:06:02','2026-08-20 10:06:03','Start update metrics...\nSuccess updated!\n','',1,14),(174,'2026-08-20 10:06:02','2026-08-20 10:06:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(175,'2026-08-20 10:06:02','2026-08-20 10:06:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(176,'2026-08-20 10:06:02','2026-08-20 10:06:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(177,'2026-08-20 10:07:02','2026-08-20 10:07:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(178,'2026-08-20 10:08:01','2026-08-20 10:08:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(179,'2026-08-20 10:08:01','2026-08-20 10:08:02','Recalculated. Count affected keys = 0\n','',1,7),(180,'2026-08-20 10:08:01','2026-08-20 10:08:02','Start update metrics...\nSuccess updated!\n','',1,14),(181,'2026-08-20 10:08:01','2026-08-20 10:08:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(182,'2026-08-20 10:08:01','2026-08-20 10:08:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(183,'2026-08-20 10:08:01','2026-08-20 10:08:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(184,'2026-08-20 10:09:01','2026-08-20 10:09:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(185,'2026-08-21 09:35:19','2026-08-21 09:36:20','Found 25 rules in storage, try apply\nSuccess!\n','',1,10),(186,'2026-08-21 09:35:19','2026-08-21 09:35:21','','',1,25),(187,'2026-08-21 09:36:02','2026-08-21 09:36:03','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(188,'2026-08-21 09:36:02','2026-08-21 09:36:03','Recalculated. Count affected keys = 0\n','',1,7),(189,'2026-08-21 09:36:02','2026-08-21 09:37:03','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(190,'2026-08-21 09:36:02','2026-08-21 09:36:03','Start update metrics...\nSuccess updated!\n','',1,14),(191,'2026-08-21 09:36:02','2026-08-21 09:36:03','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(192,'2026-08-21 09:36:02','2026-08-21 09:36:03','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(193,'2026-08-21 09:36:02','2026-08-21 09:36:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(194,'2026-08-21 09:37:02','2026-08-21 09:38:03','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(195,'2026-08-21 09:37:02','2026-08-21 09:37:03','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27),(196,'2026-08-21 09:38:01','2026-08-21 09:38:02','Start write sys metrics\nWrite components metrics\nWrite schedules info\nWrite device interface tags and starred\n','',1,6),(197,'2026-08-21 09:38:01','2026-08-21 09:38:02','Recalculated. Count affected keys = 0\n','',1,7),(198,'2026-08-21 09:38:01','2026-08-21 09:39:02','Found 25 rules in storage, try apply\nSuccess!\n','',1,11),(199,'2026-08-21 09:38:01','2026-08-21 09:38:02','Start update metrics...\nSuccess updated!\n','',1,14),(200,'2026-08-21 09:38:01','2026-08-21 09:38:02','+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n| Link ID | Source device | Source interface | Destination device | Destination interface | Speed (Mbits) | Utilization (%) | Utilization (Mbps) |\n+---------+---------------+------------------+--------------------+-----------------------+---------------+-----------------+--------------------+\n','',1,18),(201,'2026-08-21 09:38:01','2026-08-21 09:38:02','+-------+------+------------+--------+--------+\n| first | last | macAddress | vlanID | ifaces |\n+-------+------+------------+--------+--------+\n+-------+------+-------+--------+\n| first | last | Ident | ifaces |\n+-------+------+-------+--------+\n','',1,23),(202,'2026-08-21 09:38:01','2026-08-21 09:38:02','+---------+------+-------+------+-------+---------+\n| Path ID | Name | Group | Prio | State | Changed |\n+---------+------+-------+------+-------+---------+\n\n+-------+-------+--------+-------+-----------+\n| Group | State | Usable | Total | Protected |\n+-------+-------+--------+-------+-----------+\n\nEvaluated 0 path(s), 0 state change(s), metrics exported\n','',1,27);
/*!40000 ALTER TABLE `system_schedule_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_auth_keys`
--

DROP TABLE IF EXISTS `user_auth_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_auth_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `key` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `expired_at` datetime NOT NULL,
  `remote_addr` varchar(50) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `status` enum('ACTIVE','EXPIRED','CLOSED') NOT NULL DEFAULT 'ACTIVE',
  `last_activity` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `device_info` json DEFAULT NULL,
  `is_manual` tinyint NOT NULL DEFAULT '0',
  `description` varchar(500) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_auth_keys_key_uindex` (`key`),
  KEY `user_auth_keys_users_id_fk` (`user_id`),
  CONSTRAINT `user_auth_keys_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_auth_keys`
--

LOCK TABLES `user_auth_keys` WRITE;
/*!40000 ALTER TABLE `user_auth_keys` DISABLE KEYS */;
INSERT INTO `user_auth_keys` VALUES (1,1,'8b8fc82e-b4cd-417c-8223-540867279dad','2026-08-17 18:12:41','2026-08-27 18:12:41','192.168.137.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','CLOSED','2026-08-18 08:42:19','{\"bot\": null, \"brand\": \"\", \"model\": \"\", \"client\": {\"name\": \"Chrome\", \"type\": \"browser\", \"engine\": \"Blink\", \"family\": \"Chrome\", \"version\": \"151.0.0.0\", \"short_name\": \"CH\", \"engine_version\": \"151.0.0.0\"}, \"device\": \"desktop\", \"os_info\": {\"name\": \"Windows\", \"family\": \"Windows\", \"version\": \"10\", \"platform\": \"x64\", \"short_name\": \"WIN\"}}',0,''),(2,1,'2679904b-6d64-4978-bb4d-80ad6621f0e0','2026-08-18 08:13:01','2026-08-28 08:13:01','192.168.137.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','CLOSED','2026-08-18 08:33:59','{\"bot\": null, \"brand\": \"\", \"model\": \"\", \"client\": {\"name\": \"Chrome\", \"type\": \"browser\", \"engine\": \"Blink\", \"family\": \"Chrome\", \"version\": \"151.0.0.0\", \"short_name\": \"CH\", \"engine_version\": \"151.0.0.0\"}, \"device\": \"desktop\", \"os_info\": {\"name\": \"Windows\", \"family\": \"Windows\", \"version\": \"10\", \"platform\": \"x64\", \"short_name\": \"WIN\"}}',0,''),(3,1,'d26b1378-8282-4272-b8d3-3c2c11750d32','2026-08-18 08:33:31','2026-08-18 08:38:31',NULL,NULL,'CLOSED','2026-08-18 08:33:59',NULL,0,''),(4,1,'7cd5a0d3-067e-40f0-995a-b20bdee02b21','2026-08-18 08:33:49','2026-08-18 08:38:49',NULL,NULL,'CLOSED','2026-08-18 08:33:59',NULL,0,''),(5,1,'d05945f0-6419-4cd2-9c74-4b2bf845b926','2026-08-18 08:46:18','2026-08-28 08:46:18','192.168.137.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','ACTIVE','2026-08-20 10:08:46','{\"bot\": null, \"brand\": \"\", \"model\": \"\", \"client\": {\"name\": \"Chrome\", \"type\": \"browser\", \"engine\": \"Blink\", \"family\": \"Chrome\", \"version\": \"151.0.0.0\", \"short_name\": \"CH\", \"engine_version\": \"151.0.0.0\"}, \"device\": \"desktop\", \"os_info\": {\"name\": \"Windows\", \"family\": \"Windows\", \"version\": \"10\", \"platform\": \"x64\", \"short_name\": \"WIN\"}}',0,'');
/*!40000 ALTER TABLE `user_auth_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_devices_groups`
--

DROP TABLE IF EXISTS `user_devices_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_devices_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_devices_groups_user_id_group_id_uindex` (`user_id`,`group_id`),
  KEY `user_devices_groups_device_groups_id_fk` (`group_id`),
  CONSTRAINT `user_devices_groups_device_groups_id_fk` FOREIGN KEY (`group_id`) REFERENCES `device_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_devices_groups_users_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_devices_groups`
--

LOCK TABLES `user_devices_groups` WRITE;
/*!40000 ALTER TABLE `user_devices_groups` DISABLE KEYS */;
INSERT INTO `user_devices_groups` VALUES (3,'2026-08-20 10:08:59',-1,1);
/*!40000 ALTER TABLE `user_devices_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display` varchar(255) DEFAULT NULL,
  `permissions` json DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (-2,'Owner','1','[]','System owner'),(-1,'System','0','[]',''),(7,'Installer','1','[\"system_info\", \"dashboard_edit\", \"global_search\", \"user_self\", \"device_show\", \"switches_info\", \"prom_chart_info\", \"live_traffic_info\", \"fdb_history_by_interface\", \"unregistered_onts\", \"events_show\", \"pon_boxes_view\", \"router_os_info\", \"user_self_control\", \"olts_info\", \"poller_info_by_device\", \"links_view\"]',''),(8,'Operator','1','[\"system_info\", \"dashboard_edit\", \"global_search\", \"user_self\", \"device_show\", \"switches_info\", \"prom_chart_info\", \"live_traffic_info\", \"fdb_history_by_interface\", \"unregistered_onts\", \"events_show\", \"pon_boxes_view\", \"router_os_info\", \"user_self_control\", \"olts_info\", \"poller_info_by_device\", \"links_view\"]','');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `display` varchar(255) DEFAULT NULL,
  `permissions` json DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `params` json DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (-2,'Owner','1','[]','System owner',NULL),(-1,'System','0','[]','',NULL),(7,'Installer','1','[\"system_info\", \"dashboard_edit\", \"global_search\", \"user_self\", \"device_show\", \"switches_info\", \"prom_chart_info\", \"live_traffic_info\", \"fdb_history_by_interface\", \"unregistered_onts\", \"events_show\", \"pon_boxes_view\", \"router_os_info\", \"user_self_control\", \"olts_info\", \"poller_info_by_device\", \"links_view\"]','',NULL),(8,'Operator','1','[\"system_info\", \"dashboard_edit\", \"global_search\", \"user_self\", \"device_show\", \"switches_info\", \"prom_chart_info\", \"live_traffic_info\", \"fdb_history_by_interface\", \"unregistered_onts\", \"events_show\", \"pon_boxes_view\", \"router_os_info\", \"user_self_control\", \"olts_info\", \"poller_info_by_device\", \"links_view\"]','',NULL);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `role_id` int NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` enum('DISABLED','ENABLED') NOT NULL DEFAULT 'ENABLED',
  `language` enum('ru','en','ua') NOT NULL DEFAULT 'en',
  `settings` json DEFAULT NULL,
  `is_twofa` tinyint(1) DEFAULT '0',
  `twofa_token` varchar(255) DEFAULT NULL,
  `twofa_remember` tinyint(1) DEFAULT '0',
  `twofa_attempt` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login_uindex` (`login`),
  KEY `users_user_groups_id_fk` (`role_id`),
  CONSTRAINT `users_user_groups_id_fk` FOREIGN KEY (`role_id`) REFERENCES `user_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (-5,'alertmanager','Alertmanager','2026-04-14 14:48:46','2026-04-14 14:48:46',-1,NULL,'ENABLED','en',NULL,0,NULL,0,0),(-3,'cron','System events','2021-03-15 23:34:05','2021-03-15 23:34:13',-1,'event','ENABLED','en',NULL,0,NULL,0,0),(-2,'console','console','2021-02-15 22:02:26','2021-02-15 22:02:29',-1,'console','ENABLED','en',NULL,0,NULL,0,0),(-1,'sys','system','2021-02-13 20:38:20','2021-02-13 20:38:20',-1,'system','ENABLED','en',NULL,0,NULL,0,0),(1,'admin','Admin','2026-08-18 08:13:01','2026-08-20 10:08:59',-2,'$2y$10$BF5xTN1UgHEMCqEfp.ku..SHhfvDzDln0F5HWAycBZtbhbqMMYuYC','ENABLED','en','{\"lang\": \"ru\", \"device\": {\"breadcrumb_show\": \"ip\", \"expand_pon_tree\": true, \"interfaces_stat_type\": \"all\"}, \"global\": {\"notification_place\": \"topRight\"}, \"device_dashboard\": {\"sort_by\": \"ip\", \"show_groups\": true, \"down_devices_on_top\": true}, \"dashboard_template\": {\"\": [{\"h\": 10, \"i\": \"9\", \"w\": 2, \"x\": 0, \"y\": 25, \"moved\": false, \"static\": false, \"widget\": \"bad_ont_signal\"}, {\"h\": 12, \"i\": \"7\", \"w\": 1, \"x\": 0, \"y\": 74, \"moved\": false, \"static\": false, \"widget\": \"events_stat_by_name\"}, {\"h\": 13, \"i\": \"6\", \"w\": 1, \"x\": 0, \"y\": 12, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 11, \"i\": \"5\", \"w\": 1, \"x\": 0, \"y\": 63, \"moved\": false, \"static\": false, \"widget\": \"system_stat\"}, {\"h\": 12, \"i\": \"4\", \"w\": 8, \"x\": 0, \"y\": 86, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 13, \"i\": \"3\", \"w\": 1, \"x\": 0, \"y\": 50, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 15, \"i\": \"2\", \"w\": 1, \"x\": 0, \"y\": 35, \"moved\": false, \"static\": false, \"widget\": \"events_stat\"}, {\"h\": 12, \"i\": \"1\", \"w\": 1, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}], \"lg\": [{\"h\": 11, \"i\": \"16\", \"w\": 2, \"x\": 20, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"bad_ont_signal\"}, {\"h\": 14, \"i\": \"15\", \"w\": 11, \"x\": 0, \"y\": 47, \"moved\": false, \"static\": false, \"widget\": \"unregistered_onts\"}, {\"h\": 12, \"i\": \"14\", \"w\": 6, \"x\": 6, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 14, \"i\": \"13\", \"w\": 9, \"x\": 11, \"y\": 12, \"moved\": false, \"static\": false, \"widget\": \"device_status_chart\"}, {\"h\": 14, \"i\": \"12\", \"w\": 11, \"x\": 0, \"y\": 12, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 12, \"i\": \"11\", \"w\": 8, \"x\": 12, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 21, \"i\": \"10\", \"w\": 13, \"x\": 11, \"y\": 26, \"moved\": false, \"static\": false, \"widget\": \"last_user_activity\"}, {\"h\": 21, \"i\": \"7\", \"w\": 11, \"x\": 0, \"y\": 26, \"moved\": false, \"static\": false, \"widget\": \"device_calling_errors_stat\"}, {\"h\": 11, \"i\": \"6\", \"w\": 11, \"x\": 0, \"y\": 71, \"moved\": false, \"static\": false, \"widget\": \"system_stat\"}, {\"h\": 32, \"i\": \"4\", \"w\": 13, \"x\": 11, \"y\": 47, \"moved\": false, \"static\": false, \"widget\": \"events_table\"}, {\"h\": 10, \"i\": \"3\", \"w\": 11, \"x\": 0, \"y\": 61, \"moved\": false, \"static\": false, \"widget\": \"events_stat_by_name\"}, {\"h\": 14, \"i\": \"2\", \"w\": 4, \"x\": 20, \"y\": 11, \"moved\": false, \"static\": false, \"widget\": \"events_stat\"}, {\"h\": 12, \"i\": \"1\", \"w\": 6, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}], \"md\": [{\"h\": 15, \"i\": \"16\", \"w\": 7, \"x\": 0, \"y\": 27, \"moved\": false, \"static\": false, \"widget\": \"device_status_chart\"}, {\"h\": 13, \"i\": \"15\", \"w\": 2, \"x\": 8, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"bad_ont_signal\"}, {\"h\": 13, \"i\": \"14\", \"w\": 3, \"x\": 3, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 14, \"i\": \"13\", \"w\": 6, \"x\": 6, \"y\": 13, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 14, \"i\": \"12\", \"w\": 6, \"x\": 0, \"y\": 13, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 22, \"i\": \"10\", \"w\": 12, \"x\": 0, \"y\": 42, \"moved\": false, \"static\": false, \"widget\": \"events_table\"}, {\"h\": 15, \"i\": \"9\", \"w\": 5, \"x\": 7, \"y\": 27, \"moved\": false, \"static\": false, \"widget\": \"events_stat_by_name\"}, {\"h\": 13, \"i\": \"8\", \"w\": 2, \"x\": 6, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"events_stat\"}, {\"h\": 13, \"i\": \"7\", \"w\": 3, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}, {\"h\": 19, \"i\": \"6\", \"w\": 5, \"x\": 0, \"y\": 64, \"moved\": false, \"static\": false, \"widget\": \"device_calling_errors_stat\"}, {\"h\": 19, \"i\": \"5\", \"w\": 7, \"x\": 5, \"y\": 64, \"moved\": false, \"static\": false, \"widget\": \"last_user_activity\"}], \"sm\": [{\"h\": 10, \"i\": \"16\", \"w\": 1, \"x\": 0, \"y\": 13, \"moved\": false, \"static\": false, \"widget\": \"bad_ont_signal\"}, {\"h\": 13, \"i\": \"15\", \"w\": 2, \"x\": 2, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 13, \"i\": \"14\", \"w\": 2, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}, {\"h\": 12, \"i\": \"11\", \"w\": 8, \"x\": 0, \"y\": 65, \"moved\": false, \"static\": false, \"widget\": \"device_status_chart\"}, {\"h\": 16, \"i\": \"10\", \"w\": 6, \"x\": 0, \"y\": 49, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 16, \"i\": \"9\", \"w\": 6, \"x\": 0, \"y\": 33, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 13, \"i\": \"8\", \"w\": 2, \"x\": 4, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"events_stat\"}, {\"h\": 20, \"i\": \"7\", \"w\": 5, \"x\": 1, \"y\": 13, \"moved\": false, \"static\": false, \"widget\": \"events_table\"}, {\"h\": 17, \"i\": \"6\", \"w\": 6, \"x\": 0, \"y\": 77, \"moved\": false, \"static\": false, \"widget\": \"device_calling_errors_stat\"}, {\"h\": 28, \"i\": \"5\", \"w\": 6, \"x\": 0, \"y\": 94, \"moved\": false, \"static\": false, \"widget\": \"last_user_activity\"}], \"xs\": [{\"h\": 14, \"i\": \"12\", \"w\": 6, \"x\": 0, \"y\": 14, \"moved\": false, \"static\": false, \"widget\": \"unregistered_onts\"}, {\"h\": 14, \"i\": \"11\", \"w\": 3, \"x\": 3, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 15, \"i\": \"10\", \"w\": 6, \"x\": 0, \"y\": 28, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 14, \"i\": \"9\", \"w\": 6, \"x\": 0, \"y\": 43, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 11, \"i\": \"8\", \"w\": 6, \"x\": 0, \"y\": 57, \"moved\": false, \"static\": false, \"widget\": \"events_stat_by_name\"}, {\"h\": 14, \"i\": \"7\", \"w\": 3, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}, {\"h\": 13, \"i\": \"6\", \"w\": 6, \"x\": 0, \"y\": 68, \"moved\": false, \"static\": false, \"widget\": \"device_calling_errors_stat\"}, {\"h\": 22, \"i\": \"3\", \"w\": 6, \"x\": 0, \"y\": 81, \"moved\": false, \"static\": false, \"widget\": \"last_user_activity\"}], \"xss\": [], \"xxs\": [{\"h\": 10, \"i\": \"9\", \"w\": 2, \"x\": 0, \"y\": 25, \"moved\": false, \"static\": false, \"widget\": \"bad_ont_signal\"}, {\"h\": 12, \"i\": \"7\", \"w\": 1, \"x\": 0, \"y\": 74, \"moved\": false, \"static\": false, \"widget\": \"events_stat_by_name\"}, {\"h\": 13, \"i\": \"6\", \"w\": 1, \"x\": 0, \"y\": 12, \"moved\": false, \"static\": false, \"widget\": \"ont_statuses_pie\"}, {\"h\": 11, \"i\": \"5\", \"w\": 1, \"x\": 0, \"y\": 63, \"moved\": false, \"static\": false, \"widget\": \"system_stat\"}, {\"h\": 12, \"i\": \"4\", \"w\": 8, \"x\": 0, \"y\": 86, \"moved\": false, \"static\": false, \"widget\": \"online_onts_chart\"}, {\"h\": 13, \"i\": \"3\", \"w\": 1, \"x\": 0, \"y\": 50, \"moved\": false, \"static\": false, \"widget\": \"ont_signal_bar\"}, {\"h\": 15, \"i\": \"2\", \"w\": 1, \"x\": 0, \"y\": 35, \"moved\": false, \"static\": false, \"widget\": \"events_stat\"}, {\"h\": 12, \"i\": \"1\", \"w\": 1, \"x\": 0, \"y\": 0, \"moved\": false, \"static\": false, \"widget\": \"pinger_stat\"}]}, \"strict_access_by_ip\": {\"enabled\": false, \"networks\": []}}',0,NULL,0,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wca_migrations`
--

DROP TABLE IF EXISTS `wca_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wca_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wca_migrations_name_uindex` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wca_migrations`
--

LOCK TABLES `wca_migrations` WRITE;
/*!40000 ALTER TABLE `wca_migrations` DISABLE KEYS */;
INSERT INTO `wca_migrations` VALUES (1,'2026-04-14 14:48:40','sys:002_add_params_to_access'),(2,'2026-04-14 14:48:40','sys:003_add_params_to_user_groups'),(3,'2026-04-14 14:48:40','sys:004_add_controller_to_model'),(4,'2026-04-14 14:48:40','sys:005_add_fdb_collector'),(5,'2026-04-14 14:48:40','sys:006_add_new_interface_types'),(6,'2026-04-14 14:48:40','sys:007_collector_processing'),(7,'2026-04-14 14:48:40','sys:008_added_new_collectors'),(8,'2026-04-14 14:48:40','sys:009_fix_default_value_in_actions_log'),(9,'2026-04-14 14:48:40','sys:010_added_location_of_device'),(10,'2026-04-14 14:48:40','sys:011_fixed_foregein_keys'),(11,'2026-04-14 14:48:40','sys:013_add_user_languages'),(12,'2026-04-14 14:48:40','sys:014_add_schedule_crontab'),(13,'2026-04-14 14:48:40','sys:015_added_uniq_key_for_system_components'),(14,'2026-04-14 14:48:40','sys:016_added_new_system_schedule_jobs'),(15,'2026-04-14 14:48:40','sys:017_refactor_collector_proccesing'),(16,'2026-04-14 14:48:40','sys:018_added_indexes'),(17,'2026-04-14 14:48:40','sys:019_change_schedule_commands'),(18,'2026-04-14 14:48:40','sys:021_add_devices_group'),(19,'2026-04-14 14:48:40','sys:022_added_new_collectors'),(20,'2026-04-14 14:48:40','sys:023_added_new_schedule_for_prometheus'),(21,'2026-04-14 14:48:40','sys:024_remove_old_tables'),(22,'2026-04-14 14:48:40','sys:025_added_new_collectors'),(23,'2026-04-14 14:48:40','sys:026_added_editable_schedule'),(24,'2026-04-14 14:48:40','sys:027_added_system_sessions_recalc'),(25,'2026-04-14 14:48:40','sys:028_update_collector'),(26,'2026-04-14 14:48:40','sys:030_added_collectors_to_device'),(27,'2026-04-14 14:48:40','sys:031_added_collector_sys_resources'),(28,'2026-04-14 14:48:40','sys:032_fix_migration_name_length'),(29,'2026-04-14 14:48:40','sys:033_added_type_ge'),(30,'2026-04-14 14:48:40','sys:034_added_online_status'),(31,'2026-04-14 14:48:40','sys:035_added_uniq_migration'),(32,'2026-04-14 14:48:40','sys:036_refactor'),(33,'2026-04-14 14:48:40','sys:037_fix_foregein_keys'),(34,'2026-04-14 14:48:40','sys:038_remove_rpc'),(35,'2026-04-14 14:48:40','sys:039_add_schedule'),(36,'2026-04-14 14:48:40','sys:040_added_parent_iface'),(37,'2026-04-14 14:48:40','sys:041_added_comment'),(38,'2026-04-14 14:48:40','sys:042_added_new_interface_type'),(39,'2026-04-14 14:48:40','sys:043_update_for_v0_17'),(40,'2026-04-14 14:48:40','sys:044_added_supporting_tags'),(41,'2026-04-14 14:48:40','sys:045_adding_new_device_type'),(42,'2026-04-14 14:48:40','sys:046_adding_vendor_info'),(43,'2026-04-14 14:48:40','sys:048_remove_old_subscr_check'),(44,'2026-04-14 14:48:40','sys:049_adding_new_poller'),(45,'2026-04-14 14:48:40','sys:050_adding_statuses'),(46,'2026-04-14 14:48:40','sys:051_adding_interfaces_type'),(47,'2026-04-14 14:48:40','sys:052_for_ver_0_22'),(48,'2026-04-14 14:48:41','sys:053_add_fields_2fa_to_users'),(49,'2026-04-14 14:48:41','sys:054_iface_history'),(50,'2026-04-14 14:48:41','sys:055_adding_l3'),(51,'2026-04-14 14:48:41','sys:056_adding_encryption'),(52,'2026-04-14 14:48:41','sys:057_adding_routeros'),(53,'2026-04-14 14:48:41','sys:058_fix_schedule'),(54,'2026-04-14 14:48:41','sys:059_fix_schedule'),(55,'2026-04-14 14:48:41','sys:060_added_key_manual'),(56,'2026-04-14 14:48:41','sys:061_remove_2fa_global'),(57,'2026-04-14 14:48:46','events:01_init'),(58,'2026-04-14 14:48:46','events:02_added_alertmanager_config'),(59,'2026-04-14 14:48:46','events:03_added_index_for_key'),(60,'2026-04-14 14:48:46','events:04_added_new_events'),(61,'2026-04-14 14:48:46','events:05_added_crontab_for_apply'),(62,'2026-04-14 14:48:46','events:06_added_new_indexes'),(63,'2026-04-14 14:48:46','events:07_recreate_rules'),(64,'2026-04-14 14:48:46','events:08_adding_retention_cron'),(65,'2026-04-14 14:48:46','events:09_adding_new_event'),(66,'2026-04-14 14:48:46','events:10_adding_internal'),(67,'2026-04-14 14:48:47','mikbill_integration:01_init'),(68,'2026-04-14 14:48:48','prometheus_wrapper:01_init'),(69,'2026-04-14 14:48:48','olts:001_init'),(70,'2026-04-14 14:48:48','olts:002_fixed_pollers'),(71,'2026-04-14 14:48:48','olts:003_fixed_pollers'),(72,'2026-04-14 14:48:48','olts:004_adding_olts'),(73,'2026-04-14 14:48:48','olts:005_adding_olts'),(74,'2026-04-14 14:48:48','olts:006_adding_olts'),(75,'2026-04-14 14:48:48','olts:007_adding_pollers'),(76,'2026-04-14 14:48:48','olts:008_change_c_data_olts'),(77,'2026-04-14 14:48:48','olts:009_fix_c_data_fd12'),(78,'2026-04-14 14:48:48','olts:010_adding_vsol_gpon'),(79,'2026-04-14 14:48:49','olts:011_adding_gcom_old'),(80,'2026-04-14 14:48:49','olts:012_huawei_olt_fixes'),(81,'2026-04-14 14:48:49','olts:013_adding_cdata_v3'),(82,'2026-04-14 14:48:49','olts:014_adding_cdata_fd1604'),(83,'2026-04-14 14:48:49','olts:015_adding_cdata_fd1601'),(84,'2026-04-14 14:48:49','olts:016_added_sys_resources'),(85,'2026-04-14 14:48:49','live_traffic:01_init'),(86,'2026-04-14 14:48:50','pinger:01_init'),(87,'2026-04-14 14:48:50','pinger:02_added_crontab'),(88,'2026-04-14 14:48:51','fdb_history:01_init'),(89,'2026-04-14 14:48:51','fdb_history:02_fix_duplicates'),(90,'2026-04-14 14:48:52','autodiscovery:01_init'),(91,'2026-04-14 14:48:52','autodiscovery:02_added_autodisc'),(92,'2026-04-14 14:48:52','diagnostic:01_init'),(93,'2026-04-14 14:48:53','router_os:01_init_module'),(94,'2026-04-14 14:48:53','router_os:02_added_controller'),(95,'2026-04-14 14:48:53','router_os:03_added_collector_sys_resources'),(96,'2026-04-14 14:48:53','router_os:04_added_collector_system'),(97,'2026-04-14 14:48:53','router_os:05_added_new_models'),(98,'2026-04-14 14:48:53','router_os:06_model_fix'),(99,'2026-04-14 14:48:53','router_os:07_refactor_poller'),(100,'2026-04-14 14:48:53','router_os:08_added_models'),(101,'2026-04-14 14:48:53','router_os:09_added_sys_resources'),(102,'2026-04-14 14:48:54','search_device:01_init'),(103,'2026-04-14 14:48:55','userside_integration:01_init'),(104,'2026-04-14 14:48:55','qr-generator:01_init'),(105,'2026-04-14 14:48:56','oxidized:01_init'),(106,'2026-04-14 14:48:57','switches:001_init'),(107,'2026-04-14 14:48:57','switches:002_fixed_pollers'),(108,'2026-04-14 14:48:57','switches:003_added_new_models'),(109,'2026-04-14 14:48:57','switches:004_added_new_models'),(110,'2026-04-14 14:48:57','switches:005_added_new_models'),(111,'2026-04-14 14:48:57','switches:006_adding_new_models'),(112,'2026-04-14 14:48:57','switches:007_adding_huawei_s93xx'),(113,'2026-04-14 14:48:57','switches:008_adding_juniper'),(114,'2026-04-14 14:48:57','switches:009_adding_at'),(115,'2026-04-14 14:48:57','switches:010_adding_dlink'),(116,'2026-04-14 14:48:57','switches:012_update_mikro'),(117,'2026-04-14 14:48:57','switches:013_adding_dlink'),(118,'2026-04-14 14:48:57','switches:014_adding_aruba'),(119,'2026-04-14 14:48:57','switches:015_adding_raisecom_2600'),(120,'2026-04-14 14:48:57','switches:016_adding_arista'),(121,'2026-04-14 14:48:57','switches:017_adding_dcn'),(122,'2026-04-14 14:48:57','switches:018_adding_raisecom_default'),(123,'2026-04-14 14:48:57','switches:019_adding_raisecom_rax721'),(124,'2026-04-14 14:48:57','switches:020_adding_cdata_fd5008'),(125,'2026-04-14 14:48:57','switches:021_adding_swos_default'),(126,'2026-04-14 14:48:57','switches:022_adding_dlink_switches'),(127,'2026-04-14 14:48:57','switches:023_adding_eltex_switches'),(128,'2026-04-14 14:48:58','nodeny_plus:01_init'),(129,'2026-04-14 14:48:58','pon_boxes:01_init'),(130,'2026-04-14 14:48:58','pon_boxes:02_add_status_for_objects'),(131,'2026-04-14 14:48:59','pon_boxes:03_fill_tables'),(132,'2026-04-14 14:48:59','olts_control:01_init'),(133,'2026-04-14 14:49:00','sensor_devices:001_init'),(134,'2026-04-14 14:49:01','switches_control:01_init_module'),(135,'2026-04-14 14:49:02','links:01_init'),(136,'2026-04-14 14:49:02','links:02_adding_params'),(137,'2026-04-14 14:49:02','links:03_adding_metrics'),(138,'2026-04-14 14:49:03','notifications:01_init'),(139,'2026-04-14 14:49:03','notifications:02_added_new_notifications'),(140,'2026-04-14 14:49:03','notifications:03_added_check_uplinks'),(141,'2026-04-14 14:49:03','notifications:04_added_new_indexes'),(142,'2026-04-14 14:49:03','notifications:05_clearing'),(143,'2026-04-14 14:49:04','macros:01_init'),(144,'2026-04-14 14:49:04','macros:02_adding_macro'),(145,'2026-04-14 14:49:05','onts_registration:01_init'),(146,'2026-04-14 14:49:06','auto_topology:01_init'),(147,'2026-04-14 14:49:07','attachments:01_init'),(148,'2026-04-14 14:49:08','console:01_init'),(149,'2026-04-14 14:49:09','analytics:01_init'),(150,'2026-04-14 14:49:09','analytics:02_added_schedule'),(151,'2026-04-14 14:49:09','analytics:03_alertmanager_rules'),(152,'2026-04-14 14:49:09','analytics:04_alertmanager_rules'),(153,'2026-04-14 14:49:10','routers:001_adding_routers'),(154,'2026-04-14 14:49:10','routers:002_added_sys_resources'),(155,'2026-04-14 14:49:10','routers:003_move_arista_to_routers'),(156,'2026-04-14 14:49:11','trapservice:01_init'),(157,'2026-08-17 16:54:10','sys:061_added_cron_job'),(158,'2026-08-17 16:54:28','events:11_adding_sync_active_alerts_cron'),(159,'2026-08-17 16:54:28','olts:017_adding_c_data_fd1700s_fw3'),(160,'2026-08-17 19:03:18','paths:01_init');
/*!40000 ALTER TABLE `wca_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-21  9:39:05
